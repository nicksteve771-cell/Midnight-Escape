"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/ws/lib/constants.js
var require_constants = __commonJS({
  "node_modules/ws/lib/constants.js"(exports2, module2) {
    "use strict";
    var BINARY_TYPES = ["nodebuffer", "arraybuffer", "fragments"];
    var hasBlob = typeof Blob !== "undefined";
    if (hasBlob) BINARY_TYPES.push("blob");
    module2.exports = {
      BINARY_TYPES,
      CLOSE_TIMEOUT: 3e4,
      EMPTY_BUFFER: Buffer.alloc(0),
      GUID: "258EAFA5-E914-47DA-95CA-C5AB0DC85B11",
      hasBlob,
      kForOnEventAttribute: /* @__PURE__ */ Symbol("kIsForOnEventAttribute"),
      kListener: /* @__PURE__ */ Symbol("kListener"),
      kStatusCode: /* @__PURE__ */ Symbol("status-code"),
      kWebSocket: /* @__PURE__ */ Symbol("websocket"),
      NOOP: () => {
      }
    };
  }
});

// node_modules/ws/lib/buffer-util.js
var require_buffer_util = __commonJS({
  "node_modules/ws/lib/buffer-util.js"(exports2, module2) {
    "use strict";
    var { EMPTY_BUFFER } = require_constants();
    var FastBuffer = Buffer[Symbol.species];
    function concat(list, totalLength) {
      if (list.length === 0) return EMPTY_BUFFER;
      if (list.length === 1) return list[0];
      const target = Buffer.allocUnsafe(totalLength);
      let offset = 0;
      for (let i = 0; i < list.length; i++) {
        const buf = list[i];
        target.set(buf, offset);
        offset += buf.length;
      }
      if (offset < totalLength) {
        return new FastBuffer(target.buffer, target.byteOffset, offset);
      }
      return target;
    }
    function _mask(source, mask, output, offset, length) {
      for (let i = 0; i < length; i++) {
        output[offset + i] = source[i] ^ mask[i & 3];
      }
    }
    function _unmask(buffer, mask) {
      for (let i = 0; i < buffer.length; i++) {
        buffer[i] ^= mask[i & 3];
      }
    }
    function toArrayBuffer(buf) {
      if (buf.length === buf.buffer.byteLength) {
        return buf.buffer;
      }
      return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.length);
    }
    function toBuffer(data) {
      toBuffer.readOnly = true;
      if (Buffer.isBuffer(data)) return data;
      let buf;
      if (data instanceof ArrayBuffer) {
        buf = new FastBuffer(data);
      } else if (ArrayBuffer.isView(data)) {
        buf = new FastBuffer(data.buffer, data.byteOffset, data.byteLength);
      } else {
        buf = Buffer.from(data);
        toBuffer.readOnly = false;
      }
      return buf;
    }
    module2.exports = {
      concat,
      mask: _mask,
      toArrayBuffer,
      toBuffer,
      unmask: _unmask
    };
    if (!process.env.WS_NO_BUFFER_UTIL) {
      try {
        const bufferUtil = require("bufferutil");
        module2.exports.mask = function(source, mask, output, offset, length) {
          if (length < 48) _mask(source, mask, output, offset, length);
          else bufferUtil.mask(source, mask, output, offset, length);
        };
        module2.exports.unmask = function(buffer, mask) {
          if (buffer.length < 32) _unmask(buffer, mask);
          else bufferUtil.unmask(buffer, mask);
        };
      } catch (e) {
      }
    }
  }
});

// node_modules/ws/lib/limiter.js
var require_limiter = __commonJS({
  "node_modules/ws/lib/limiter.js"(exports2, module2) {
    "use strict";
    var kDone = /* @__PURE__ */ Symbol("kDone");
    var kRun = /* @__PURE__ */ Symbol("kRun");
    var Limiter = class {
      /**
       * Creates a new `Limiter`.
       *
       * @param {Number} [concurrency=Infinity] The maximum number of jobs allowed
       *     to run concurrently
       */
      constructor(concurrency) {
        this[kDone] = () => {
          this.pending--;
          this[kRun]();
        };
        this.concurrency = concurrency || Infinity;
        this.jobs = [];
        this.pending = 0;
      }
      /**
       * Adds a job to the queue.
       *
       * @param {Function} job The job to run
       * @public
       */
      add(job) {
        this.jobs.push(job);
        this[kRun]();
      }
      /**
       * Removes a job from the queue and runs it if possible.
       *
       * @private
       */
      [kRun]() {
        if (this.pending === this.concurrency) return;
        if (this.jobs.length) {
          const job = this.jobs.shift();
          this.pending++;
          job(this[kDone]);
        }
      }
    };
    module2.exports = Limiter;
  }
});

// node_modules/ws/lib/permessage-deflate.js
var require_permessage_deflate = __commonJS({
  "node_modules/ws/lib/permessage-deflate.js"(exports2, module2) {
    "use strict";
    var zlib = require("zlib");
    var bufferUtil = require_buffer_util();
    var Limiter = require_limiter();
    var { kStatusCode } = require_constants();
    var FastBuffer = Buffer[Symbol.species];
    var TRAILER = Buffer.from([0, 0, 255, 255]);
    var kPerMessageDeflate = /* @__PURE__ */ Symbol("permessage-deflate");
    var kTotalLength = /* @__PURE__ */ Symbol("total-length");
    var kCallback = /* @__PURE__ */ Symbol("callback");
    var kBuffers = /* @__PURE__ */ Symbol("buffers");
    var kError = /* @__PURE__ */ Symbol("error");
    var zlibLimiter;
    var PerMessageDeflate2 = class {
      /**
       * Creates a PerMessageDeflate instance.
       *
       * @param {Object} [options] Configuration options
       * @param {(Boolean|Number)} [options.clientMaxWindowBits] Advertise support
       *     for, or request, a custom client window size
       * @param {Boolean} [options.clientNoContextTakeover=false] Advertise/
       *     acknowledge disabling of client context takeover
       * @param {Number} [options.concurrencyLimit=10] The number of concurrent
       *     calls to zlib
       * @param {Boolean} [options.isServer=false] Create the instance in either
       *     server or client mode
       * @param {Number} [options.maxPayload=0] The maximum allowed message length
       * @param {(Boolean|Number)} [options.serverMaxWindowBits] Request/confirm the
       *     use of a custom server window size
       * @param {Boolean} [options.serverNoContextTakeover=false] Request/accept
       *     disabling of server context takeover
       * @param {Number} [options.threshold=1024] Size (in bytes) below which
       *     messages should not be compressed if context takeover is disabled
       * @param {Object} [options.zlibDeflateOptions] Options to pass to zlib on
       *     deflate
       * @param {Object} [options.zlibInflateOptions] Options to pass to zlib on
       *     inflate
       */
      constructor(options) {
        this._options = options || {};
        this._threshold = this._options.threshold !== void 0 ? this._options.threshold : 1024;
        this._maxPayload = this._options.maxPayload | 0;
        this._isServer = !!this._options.isServer;
        this._deflate = null;
        this._inflate = null;
        this.params = null;
        if (!zlibLimiter) {
          const concurrency = this._options.concurrencyLimit !== void 0 ? this._options.concurrencyLimit : 10;
          zlibLimiter = new Limiter(concurrency);
        }
      }
      /**
       * @type {String}
       */
      static get extensionName() {
        return "permessage-deflate";
      }
      /**
       * Create an extension negotiation offer.
       *
       * @return {Object} Extension parameters
       * @public
       */
      offer() {
        const params = {};
        if (this._options.serverNoContextTakeover) {
          params.server_no_context_takeover = true;
        }
        if (this._options.clientNoContextTakeover) {
          params.client_no_context_takeover = true;
        }
        if (this._options.serverMaxWindowBits) {
          params.server_max_window_bits = this._options.serverMaxWindowBits;
        }
        if (this._options.clientMaxWindowBits) {
          params.client_max_window_bits = this._options.clientMaxWindowBits;
        } else if (this._options.clientMaxWindowBits == null) {
          params.client_max_window_bits = true;
        }
        return params;
      }
      /**
       * Accept an extension negotiation offer/response.
       *
       * @param {Array} configurations The extension negotiation offers/reponse
       * @return {Object} Accepted configuration
       * @public
       */
      accept(configurations) {
        configurations = this.normalizeParams(configurations);
        this.params = this._isServer ? this.acceptAsServer(configurations) : this.acceptAsClient(configurations);
        return this.params;
      }
      /**
       * Releases all resources used by the extension.
       *
       * @public
       */
      cleanup() {
        if (this._inflate) {
          this._inflate.close();
          this._inflate = null;
        }
        if (this._deflate) {
          const callback = this._deflate[kCallback];
          this._deflate.close();
          this._deflate = null;
          if (callback) {
            callback(
              new Error(
                "The deflate stream was closed while data was being processed"
              )
            );
          }
        }
      }
      /**
       *  Accept an extension negotiation offer.
       *
       * @param {Array} offers The extension negotiation offers
       * @return {Object} Accepted configuration
       * @private
       */
      acceptAsServer(offers) {
        const opts = this._options;
        const accepted = offers.find((params) => {
          if (opts.serverNoContextTakeover === false && params.server_no_context_takeover || params.server_max_window_bits && (opts.serverMaxWindowBits === false || typeof opts.serverMaxWindowBits === "number" && opts.serverMaxWindowBits > params.server_max_window_bits) || typeof opts.clientMaxWindowBits === "number" && (typeof params.client_max_window_bits === "number" ? opts.clientMaxWindowBits > params.client_max_window_bits : !params.client_max_window_bits)) {
            return false;
          }
          return true;
        });
        if (!accepted) {
          throw new Error("None of the extension offers can be accepted");
        }
        if (opts.serverNoContextTakeover) {
          accepted.server_no_context_takeover = true;
        }
        if (opts.clientNoContextTakeover) {
          accepted.client_no_context_takeover = true;
        }
        if (typeof opts.serverMaxWindowBits === "number") {
          accepted.server_max_window_bits = opts.serverMaxWindowBits;
        }
        if (typeof opts.clientMaxWindowBits === "number") {
          accepted.client_max_window_bits = opts.clientMaxWindowBits;
        } else if (accepted.client_max_window_bits === true || opts.clientMaxWindowBits === false) {
          delete accepted.client_max_window_bits;
        }
        return accepted;
      }
      /**
       * Accept the extension negotiation response.
       *
       * @param {Array} response The extension negotiation response
       * @return {Object} Accepted configuration
       * @private
       */
      acceptAsClient(response) {
        const params = response[0];
        if (this._options.clientNoContextTakeover === false && params.client_no_context_takeover) {
          throw new Error('Unexpected parameter "client_no_context_takeover"');
        }
        if (!params.client_max_window_bits) {
          if (typeof this._options.clientMaxWindowBits === "number") {
            params.client_max_window_bits = this._options.clientMaxWindowBits;
          }
        } else if (this._options.clientMaxWindowBits === false || typeof this._options.clientMaxWindowBits === "number" && params.client_max_window_bits > this._options.clientMaxWindowBits) {
          throw new Error(
            'Unexpected or invalid parameter "client_max_window_bits"'
          );
        }
        return params;
      }
      /**
       * Normalize parameters.
       *
       * @param {Array} configurations The extension negotiation offers/reponse
       * @return {Array} The offers/response with normalized parameters
       * @private
       */
      normalizeParams(configurations) {
        configurations.forEach((params) => {
          Object.keys(params).forEach((key) => {
            let value = params[key];
            if (value.length > 1) {
              throw new Error(`Parameter "${key}" must have only a single value`);
            }
            value = value[0];
            if (key === "client_max_window_bits") {
              if (value !== true) {
                const num = +value;
                if (!Number.isInteger(num) || num < 8 || num > 15) {
                  throw new TypeError(
                    `Invalid value for parameter "${key}": ${value}`
                  );
                }
                value = num;
              } else if (!this._isServer) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
            } else if (key === "server_max_window_bits") {
              const num = +value;
              if (!Number.isInteger(num) || num < 8 || num > 15) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
              value = num;
            } else if (key === "client_no_context_takeover" || key === "server_no_context_takeover") {
              if (value !== true) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
            } else {
              throw new Error(`Unknown parameter "${key}"`);
            }
            params[key] = value;
          });
        });
        return configurations;
      }
      /**
       * Decompress data. Concurrency limited.
       *
       * @param {Buffer} data Compressed data
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @public
       */
      decompress(data, fin, callback) {
        zlibLimiter.add((done) => {
          this._decompress(data, fin, (err, result) => {
            done();
            callback(err, result);
          });
        });
      }
      /**
       * Compress data. Concurrency limited.
       *
       * @param {(Buffer|String)} data Data to compress
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @public
       */
      compress(data, fin, callback) {
        zlibLimiter.add((done) => {
          this._compress(data, fin, (err, result) => {
            done();
            callback(err, result);
          });
        });
      }
      /**
       * Decompress data.
       *
       * @param {Buffer} data Compressed data
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @private
       */
      _decompress(data, fin, callback) {
        const endpoint = this._isServer ? "client" : "server";
        if (!this._inflate) {
          const key = `${endpoint}_max_window_bits`;
          const windowBits = typeof this.params[key] !== "number" ? zlib.Z_DEFAULT_WINDOWBITS : this.params[key];
          this._inflate = zlib.createInflateRaw({
            ...this._options.zlibInflateOptions,
            windowBits
          });
          this._inflate[kPerMessageDeflate] = this;
          this._inflate[kTotalLength] = 0;
          this._inflate[kBuffers] = [];
          this._inflate.on("error", inflateOnError);
          this._inflate.on("data", inflateOnData);
        }
        this._inflate[kCallback] = callback;
        this._inflate.write(data);
        if (fin) this._inflate.write(TRAILER);
        this._inflate.flush(() => {
          const err = this._inflate[kError];
          if (err) {
            this._inflate.close();
            this._inflate = null;
            callback(err);
            return;
          }
          const data2 = bufferUtil.concat(
            this._inflate[kBuffers],
            this._inflate[kTotalLength]
          );
          if (this._inflate._readableState.endEmitted) {
            this._inflate.close();
            this._inflate = null;
          } else {
            this._inflate[kTotalLength] = 0;
            this._inflate[kBuffers] = [];
            if (fin && this.params[`${endpoint}_no_context_takeover`]) {
              this._inflate.reset();
            }
          }
          callback(null, data2);
        });
      }
      /**
       * Compress data.
       *
       * @param {(Buffer|String)} data Data to compress
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @private
       */
      _compress(data, fin, callback) {
        const endpoint = this._isServer ? "server" : "client";
        if (!this._deflate) {
          const key = `${endpoint}_max_window_bits`;
          const windowBits = typeof this.params[key] !== "number" ? zlib.Z_DEFAULT_WINDOWBITS : this.params[key];
          this._deflate = zlib.createDeflateRaw({
            ...this._options.zlibDeflateOptions,
            windowBits
          });
          this._deflate[kTotalLength] = 0;
          this._deflate[kBuffers] = [];
          this._deflate.on("data", deflateOnData);
        }
        this._deflate[kCallback] = callback;
        this._deflate.write(data);
        this._deflate.flush(zlib.Z_SYNC_FLUSH, () => {
          if (!this._deflate) {
            return;
          }
          let data2 = bufferUtil.concat(
            this._deflate[kBuffers],
            this._deflate[kTotalLength]
          );
          if (fin) {
            data2 = new FastBuffer(data2.buffer, data2.byteOffset, data2.length - 4);
          }
          this._deflate[kCallback] = null;
          this._deflate[kTotalLength] = 0;
          this._deflate[kBuffers] = [];
          if (fin && this.params[`${endpoint}_no_context_takeover`]) {
            this._deflate.reset();
          }
          callback(null, data2);
        });
      }
    };
    module2.exports = PerMessageDeflate2;
    function deflateOnData(chunk) {
      this[kBuffers].push(chunk);
      this[kTotalLength] += chunk.length;
    }
    function inflateOnData(chunk) {
      this[kTotalLength] += chunk.length;
      if (this[kPerMessageDeflate]._maxPayload < 1 || this[kTotalLength] <= this[kPerMessageDeflate]._maxPayload) {
        this[kBuffers].push(chunk);
        return;
      }
      this[kError] = new RangeError("Max payload size exceeded");
      this[kError].code = "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH";
      this[kError][kStatusCode] = 1009;
      this.removeListener("data", inflateOnData);
      this.reset();
    }
    function inflateOnError(err) {
      this[kPerMessageDeflate]._inflate = null;
      if (this[kError]) {
        this[kCallback](this[kError]);
        return;
      }
      err[kStatusCode] = 1007;
      this[kCallback](err);
    }
  }
});

// node_modules/ws/lib/validation.js
var require_validation = __commonJS({
  "node_modules/ws/lib/validation.js"(exports2, module2) {
    "use strict";
    var { isUtf8 } = require("buffer");
    var { hasBlob } = require_constants();
    var tokenChars = [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      // 0 - 15
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      // 16 - 31
      0,
      1,
      0,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      1,
      1,
      0,
      1,
      1,
      0,
      // 32 - 47
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      // 48 - 63
      0,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      // 64 - 79
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      1,
      1,
      // 80 - 95
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      // 96 - 111
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      1,
      0,
      1,
      0
      // 112 - 127
    ];
    function isValidStatusCode(code) {
      return code >= 1e3 && code <= 1014 && code !== 1004 && code !== 1005 && code !== 1006 || code >= 3e3 && code <= 4999;
    }
    function _isValidUTF8(buf) {
      const len = buf.length;
      let i = 0;
      while (i < len) {
        if ((buf[i] & 128) === 0) {
          i++;
        } else if ((buf[i] & 224) === 192) {
          if (i + 1 === len || (buf[i + 1] & 192) !== 128 || (buf[i] & 254) === 192) {
            return false;
          }
          i += 2;
        } else if ((buf[i] & 240) === 224) {
          if (i + 2 >= len || (buf[i + 1] & 192) !== 128 || (buf[i + 2] & 192) !== 128 || buf[i] === 224 && (buf[i + 1] & 224) === 128 || // Overlong
          buf[i] === 237 && (buf[i + 1] & 224) === 160) {
            return false;
          }
          i += 3;
        } else if ((buf[i] & 248) === 240) {
          if (i + 3 >= len || (buf[i + 1] & 192) !== 128 || (buf[i + 2] & 192) !== 128 || (buf[i + 3] & 192) !== 128 || buf[i] === 240 && (buf[i + 1] & 240) === 128 || // Overlong
          buf[i] === 244 && buf[i + 1] > 143 || buf[i] > 244) {
            return false;
          }
          i += 4;
        } else {
          return false;
        }
      }
      return true;
    }
    function isBlob(value) {
      return hasBlob && typeof value === "object" && typeof value.arrayBuffer === "function" && typeof value.type === "string" && typeof value.stream === "function" && (value[Symbol.toStringTag] === "Blob" || value[Symbol.toStringTag] === "File");
    }
    module2.exports = {
      isBlob,
      isValidStatusCode,
      isValidUTF8: _isValidUTF8,
      tokenChars
    };
    if (isUtf8) {
      module2.exports.isValidUTF8 = function(buf) {
        return buf.length < 24 ? _isValidUTF8(buf) : isUtf8(buf);
      };
    } else if (!process.env.WS_NO_UTF_8_VALIDATE) {
      try {
        const isValidUTF8 = require("utf-8-validate");
        module2.exports.isValidUTF8 = function(buf) {
          return buf.length < 32 ? _isValidUTF8(buf) : isValidUTF8(buf);
        };
      } catch (e) {
      }
    }
  }
});

// node_modules/ws/lib/receiver.js
var require_receiver = __commonJS({
  "node_modules/ws/lib/receiver.js"(exports2, module2) {
    "use strict";
    var { Writable } = require("stream");
    var PerMessageDeflate2 = require_permessage_deflate();
    var {
      BINARY_TYPES,
      EMPTY_BUFFER,
      kStatusCode,
      kWebSocket
    } = require_constants();
    var { concat, toArrayBuffer, unmask } = require_buffer_util();
    var { isValidStatusCode, isValidUTF8 } = require_validation();
    var FastBuffer = Buffer[Symbol.species];
    var GET_INFO = 0;
    var GET_PAYLOAD_LENGTH_16 = 1;
    var GET_PAYLOAD_LENGTH_64 = 2;
    var GET_MASK = 3;
    var GET_DATA = 4;
    var INFLATING = 5;
    var DEFER_EVENT = 6;
    var Receiver2 = class extends Writable {
      /**
       * Creates a Receiver instance.
       *
       * @param {Object} [options] Options object
       * @param {Boolean} [options.allowSynchronousEvents=true] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {String} [options.binaryType=nodebuffer] The type for binary data
       * @param {Object} [options.extensions] An object containing the negotiated
       *     extensions
       * @param {Boolean} [options.isServer=false] Specifies whether to operate in
       *     client or server mode
       * @param {Number} [options.maxBufferedChunks=0] The maximum number of
       *     buffered data chunks
       * @param {Number} [options.maxFragments=0] The maximum number of message
       *     fragments
       * @param {Number} [options.maxPayload=0] The maximum allowed message length
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       */
      constructor(options = {}) {
        super();
        this._allowSynchronousEvents = options.allowSynchronousEvents !== void 0 ? options.allowSynchronousEvents : true;
        this._binaryType = options.binaryType || BINARY_TYPES[0];
        this._extensions = options.extensions || {};
        this._isServer = !!options.isServer;
        this._maxBufferedChunks = options.maxBufferedChunks | 0;
        this._maxFragments = options.maxFragments | 0;
        this._maxPayload = options.maxPayload | 0;
        this._skipUTF8Validation = !!options.skipUTF8Validation;
        this[kWebSocket] = void 0;
        this._bufferedBytes = 0;
        this._buffers = [];
        this._compressed = false;
        this._payloadLength = 0;
        this._mask = void 0;
        this._fragmented = 0;
        this._masked = false;
        this._fin = false;
        this._opcode = 0;
        this._totalPayloadLength = 0;
        this._messageLength = 0;
        this._numFragments = 0;
        this._fragments = [];
        this._errored = false;
        this._loop = false;
        this._state = GET_INFO;
      }
      /**
       * Implements `Writable.prototype._write()`.
       *
       * @param {Buffer} chunk The chunk of data to write
       * @param {String} encoding The character encoding of `chunk`
       * @param {Function} cb Callback
       * @private
       */
      _write(chunk, encoding, cb) {
        if (this._opcode === 8 && this._state == GET_INFO) return cb();
        if (this._maxBufferedChunks > 0 && this._buffers.length >= this._maxBufferedChunks) {
          cb(
            this.createError(
              RangeError,
              "Too many buffered chunks",
              false,
              1008,
              "WS_ERR_TOO_MANY_BUFFERED_PARTS"
            )
          );
          return;
        }
        this._bufferedBytes += chunk.length;
        this._buffers.push(chunk);
        this.startLoop(cb);
      }
      /**
       * Consumes `n` bytes from the buffered data.
       *
       * @param {Number} n The number of bytes to consume
       * @return {Buffer} The consumed bytes
       * @private
       */
      consume(n) {
        this._bufferedBytes -= n;
        if (n === this._buffers[0].length) return this._buffers.shift();
        if (n < this._buffers[0].length) {
          const buf = this._buffers[0];
          this._buffers[0] = new FastBuffer(
            buf.buffer,
            buf.byteOffset + n,
            buf.length - n
          );
          return new FastBuffer(buf.buffer, buf.byteOffset, n);
        }
        const dst = Buffer.allocUnsafe(n);
        do {
          const buf = this._buffers[0];
          const offset = dst.length - n;
          if (n >= buf.length) {
            dst.set(this._buffers.shift(), offset);
          } else {
            dst.set(new Uint8Array(buf.buffer, buf.byteOffset, n), offset);
            this._buffers[0] = new FastBuffer(
              buf.buffer,
              buf.byteOffset + n,
              buf.length - n
            );
          }
          n -= buf.length;
        } while (n > 0);
        return dst;
      }
      /**
       * Starts the parsing loop.
       *
       * @param {Function} cb Callback
       * @private
       */
      startLoop(cb) {
        this._loop = true;
        do {
          switch (this._state) {
            case GET_INFO:
              this.getInfo(cb);
              break;
            case GET_PAYLOAD_LENGTH_16:
              this.getPayloadLength16(cb);
              break;
            case GET_PAYLOAD_LENGTH_64:
              this.getPayloadLength64(cb);
              break;
            case GET_MASK:
              this.getMask();
              break;
            case GET_DATA:
              this.getData(cb);
              break;
            case INFLATING:
            case DEFER_EVENT:
              this._loop = false;
              return;
          }
        } while (this._loop);
        if (!this._errored) cb();
      }
      /**
       * Reads the first two bytes of a frame.
       *
       * @param {Function} cb Callback
       * @private
       */
      getInfo(cb) {
        if (this._bufferedBytes < 2) {
          this._loop = false;
          return;
        }
        const buf = this.consume(2);
        if ((buf[0] & 48) !== 0) {
          const error = this.createError(
            RangeError,
            "RSV2 and RSV3 must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_RSV_2_3"
          );
          cb(error);
          return;
        }
        const compressed = (buf[0] & 64) === 64;
        if (compressed && !this._extensions[PerMessageDeflate2.extensionName]) {
          const error = this.createError(
            RangeError,
            "RSV1 must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_RSV_1"
          );
          cb(error);
          return;
        }
        this._fin = (buf[0] & 128) === 128;
        this._opcode = buf[0] & 15;
        this._payloadLength = buf[1] & 127;
        if (this._opcode === 0) {
          if (compressed) {
            const error = this.createError(
              RangeError,
              "RSV1 must be clear",
              true,
              1002,
              "WS_ERR_UNEXPECTED_RSV_1"
            );
            cb(error);
            return;
          }
          if (!this._fragmented) {
            const error = this.createError(
              RangeError,
              "invalid opcode 0",
              true,
              1002,
              "WS_ERR_INVALID_OPCODE"
            );
            cb(error);
            return;
          }
          this._opcode = this._fragmented;
        } else if (this._opcode === 1 || this._opcode === 2) {
          if (this._fragmented) {
            const error = this.createError(
              RangeError,
              `invalid opcode ${this._opcode}`,
              true,
              1002,
              "WS_ERR_INVALID_OPCODE"
            );
            cb(error);
            return;
          }
          this._compressed = compressed;
        } else if (this._opcode > 7 && this._opcode < 11) {
          if (!this._fin) {
            const error = this.createError(
              RangeError,
              "FIN must be set",
              true,
              1002,
              "WS_ERR_EXPECTED_FIN"
            );
            cb(error);
            return;
          }
          if (compressed) {
            const error = this.createError(
              RangeError,
              "RSV1 must be clear",
              true,
              1002,
              "WS_ERR_UNEXPECTED_RSV_1"
            );
            cb(error);
            return;
          }
          if (this._payloadLength > 125 || this._opcode === 8 && this._payloadLength === 1) {
            const error = this.createError(
              RangeError,
              `invalid payload length ${this._payloadLength}`,
              true,
              1002,
              "WS_ERR_INVALID_CONTROL_PAYLOAD_LENGTH"
            );
            cb(error);
            return;
          }
        } else {
          const error = this.createError(
            RangeError,
            `invalid opcode ${this._opcode}`,
            true,
            1002,
            "WS_ERR_INVALID_OPCODE"
          );
          cb(error);
          return;
        }
        if (!this._fin && !this._fragmented) this._fragmented = this._opcode;
        this._masked = (buf[1] & 128) === 128;
        if (this._isServer) {
          if (!this._masked) {
            const error = this.createError(
              RangeError,
              "MASK must be set",
              true,
              1002,
              "WS_ERR_EXPECTED_MASK"
            );
            cb(error);
            return;
          }
        } else if (this._masked) {
          const error = this.createError(
            RangeError,
            "MASK must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_MASK"
          );
          cb(error);
          return;
        }
        if (this._payloadLength === 126) this._state = GET_PAYLOAD_LENGTH_16;
        else if (this._payloadLength === 127) this._state = GET_PAYLOAD_LENGTH_64;
        else this.haveLength(cb);
      }
      /**
       * Gets extended payload length (7+16).
       *
       * @param {Function} cb Callback
       * @private
       */
      getPayloadLength16(cb) {
        if (this._bufferedBytes < 2) {
          this._loop = false;
          return;
        }
        this._payloadLength = this.consume(2).readUInt16BE(0);
        this.haveLength(cb);
      }
      /**
       * Gets extended payload length (7+64).
       *
       * @param {Function} cb Callback
       * @private
       */
      getPayloadLength64(cb) {
        if (this._bufferedBytes < 8) {
          this._loop = false;
          return;
        }
        const buf = this.consume(8);
        const num = buf.readUInt32BE(0);
        if (num > Math.pow(2, 53 - 32) - 1) {
          const error = this.createError(
            RangeError,
            "Unsupported WebSocket frame: payload length > 2^53 - 1",
            false,
            1009,
            "WS_ERR_UNSUPPORTED_DATA_PAYLOAD_LENGTH"
          );
          cb(error);
          return;
        }
        this._payloadLength = num * Math.pow(2, 32) + buf.readUInt32BE(4);
        this.haveLength(cb);
      }
      /**
       * Payload length has been read.
       *
       * @param {Function} cb Callback
       * @private
       */
      haveLength(cb) {
        if (this._payloadLength && this._opcode < 8) {
          this._totalPayloadLength += this._payloadLength;
          if (this._totalPayloadLength > this._maxPayload && this._maxPayload > 0) {
            const error = this.createError(
              RangeError,
              "Max payload size exceeded",
              false,
              1009,
              "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH"
            );
            cb(error);
            return;
          }
        }
        if (this._masked) this._state = GET_MASK;
        else this._state = GET_DATA;
      }
      /**
       * Reads mask bytes.
       *
       * @private
       */
      getMask() {
        if (this._bufferedBytes < 4) {
          this._loop = false;
          return;
        }
        this._mask = this.consume(4);
        this._state = GET_DATA;
      }
      /**
       * Reads data bytes.
       *
       * @param {Function} cb Callback
       * @private
       */
      getData(cb) {
        let data = EMPTY_BUFFER;
        if (this._payloadLength) {
          if (this._bufferedBytes < this._payloadLength) {
            this._loop = false;
            return;
          }
          data = this.consume(this._payloadLength);
          if (this._masked && (this._mask[0] | this._mask[1] | this._mask[2] | this._mask[3]) !== 0) {
            unmask(data, this._mask);
          }
        }
        if (this._opcode > 7) {
          this.controlMessage(data, cb);
          return;
        }
        if (this._maxFragments > 0 && ++this._numFragments > this._maxFragments) {
          const error = this.createError(
            RangeError,
            "Too many message fragments",
            false,
            1008,
            "WS_ERR_TOO_MANY_BUFFERED_PARTS"
          );
          cb(error);
          return;
        }
        if (this._compressed) {
          this._state = INFLATING;
          this.decompress(data, cb);
          return;
        }
        if (data.length) {
          this._messageLength = this._totalPayloadLength;
          this._fragments.push(data);
        }
        this.dataMessage(cb);
      }
      /**
       * Decompresses data.
       *
       * @param {Buffer} data Compressed data
       * @param {Function} cb Callback
       * @private
       */
      decompress(data, cb) {
        const perMessageDeflate = this._extensions[PerMessageDeflate2.extensionName];
        perMessageDeflate.decompress(data, this._fin, (err, buf) => {
          if (err) return cb(err);
          if (buf.length) {
            this._messageLength += buf.length;
            if (this._messageLength > this._maxPayload && this._maxPayload > 0) {
              const error = this.createError(
                RangeError,
                "Max payload size exceeded",
                false,
                1009,
                "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH"
              );
              cb(error);
              return;
            }
            this._fragments.push(buf);
          }
          this.dataMessage(cb);
          if (this._state === GET_INFO) this.startLoop(cb);
        });
      }
      /**
       * Handles a data message.
       *
       * @param {Function} cb Callback
       * @private
       */
      dataMessage(cb) {
        if (!this._fin) {
          this._state = GET_INFO;
          return;
        }
        const messageLength = this._messageLength;
        const fragments = this._fragments;
        this._totalPayloadLength = 0;
        this._messageLength = 0;
        this._fragmented = 0;
        this._numFragments = 0;
        this._fragments = [];
        if (this._opcode === 2) {
          let data;
          if (this._binaryType === "nodebuffer") {
            data = concat(fragments, messageLength);
          } else if (this._binaryType === "arraybuffer") {
            data = toArrayBuffer(concat(fragments, messageLength));
          } else if (this._binaryType === "blob") {
            data = new Blob(fragments);
          } else {
            data = fragments;
          }
          if (this._allowSynchronousEvents) {
            this.emit("message", data, true);
            this._state = GET_INFO;
          } else {
            this._state = DEFER_EVENT;
            setImmediate(() => {
              this.emit("message", data, true);
              this._state = GET_INFO;
              this.startLoop(cb);
            });
          }
        } else {
          const buf = concat(fragments, messageLength);
          if (!this._skipUTF8Validation && !isValidUTF8(buf)) {
            const error = this.createError(
              Error,
              "invalid UTF-8 sequence",
              true,
              1007,
              "WS_ERR_INVALID_UTF8"
            );
            cb(error);
            return;
          }
          if (this._state === INFLATING || this._allowSynchronousEvents) {
            this.emit("message", buf, false);
            this._state = GET_INFO;
          } else {
            this._state = DEFER_EVENT;
            setImmediate(() => {
              this.emit("message", buf, false);
              this._state = GET_INFO;
              this.startLoop(cb);
            });
          }
        }
      }
      /**
       * Handles a control message.
       *
       * @param {Buffer} data Data to handle
       * @return {(Error|RangeError|undefined)} A possible error
       * @private
       */
      controlMessage(data, cb) {
        if (this._opcode === 8) {
          if (data.length === 0) {
            this._loop = false;
            this.emit("conclude", 1005, EMPTY_BUFFER);
            this.end();
          } else {
            const code = data.readUInt16BE(0);
            if (!isValidStatusCode(code)) {
              const error = this.createError(
                RangeError,
                `invalid status code ${code}`,
                true,
                1002,
                "WS_ERR_INVALID_CLOSE_CODE"
              );
              cb(error);
              return;
            }
            const buf = new FastBuffer(
              data.buffer,
              data.byteOffset + 2,
              data.length - 2
            );
            if (!this._skipUTF8Validation && !isValidUTF8(buf)) {
              const error = this.createError(
                Error,
                "invalid UTF-8 sequence",
                true,
                1007,
                "WS_ERR_INVALID_UTF8"
              );
              cb(error);
              return;
            }
            this._loop = false;
            this.emit("conclude", code, buf);
            this.end();
          }
          this._state = GET_INFO;
          return;
        }
        if (this._allowSynchronousEvents) {
          this.emit(this._opcode === 9 ? "ping" : "pong", data);
          this._state = GET_INFO;
        } else {
          this._state = DEFER_EVENT;
          setImmediate(() => {
            this.emit(this._opcode === 9 ? "ping" : "pong", data);
            this._state = GET_INFO;
            this.startLoop(cb);
          });
        }
      }
      /**
       * Builds an error object.
       *
       * @param {function(new:Error|RangeError)} ErrorCtor The error constructor
       * @param {String} message The error message
       * @param {Boolean} prefix Specifies whether or not to add a default prefix to
       *     `message`
       * @param {Number} statusCode The status code
       * @param {String} errorCode The exposed error code
       * @return {(Error|RangeError)} The error
       * @private
       */
      createError(ErrorCtor, message, prefix, statusCode, errorCode) {
        this._loop = false;
        this._errored = true;
        const err = new ErrorCtor(
          prefix ? `Invalid WebSocket frame: ${message}` : message
        );
        Error.captureStackTrace(err, this.createError);
        err.code = errorCode;
        err[kStatusCode] = statusCode;
        return err;
      }
    };
    module2.exports = Receiver2;
  }
});

// node_modules/ws/lib/sender.js
var require_sender = __commonJS({
  "node_modules/ws/lib/sender.js"(exports2, module2) {
    "use strict";
    var { Duplex } = require("stream");
    var { randomFillSync } = require("crypto");
    var {
      types: { isUint8Array }
    } = require("util");
    var PerMessageDeflate2 = require_permessage_deflate();
    var { EMPTY_BUFFER, kWebSocket, NOOP } = require_constants();
    var { isBlob, isValidStatusCode } = require_validation();
    var { mask: applyMask, toBuffer } = require_buffer_util();
    var kByteLength = /* @__PURE__ */ Symbol("kByteLength");
    var maskBuffer = Buffer.alloc(4);
    var RANDOM_POOL_SIZE = 8 * 1024;
    var randomPool;
    var randomPoolPointer = RANDOM_POOL_SIZE;
    var DEFAULT = 0;
    var DEFLATING = 1;
    var GET_BLOB_DATA = 2;
    var Sender2 = class _Sender {
      /**
       * Creates a Sender instance.
       *
       * @param {Duplex} socket The connection socket
       * @param {Object} [extensions] An object containing the negotiated extensions
       * @param {Function} [generateMask] The function used to generate the masking
       *     key
       */
      constructor(socket, extensions, generateMask) {
        this._extensions = extensions || {};
        if (generateMask) {
          this._generateMask = generateMask;
          this._maskBuffer = Buffer.alloc(4);
        }
        this._socket = socket;
        this._firstFragment = true;
        this._compress = false;
        this._bufferedBytes = 0;
        this._queue = [];
        this._state = DEFAULT;
        this.onerror = NOOP;
        this[kWebSocket] = void 0;
      }
      /**
       * Frames a piece of data according to the HyBi WebSocket protocol.
       *
       * @param {(Buffer|String)} data The data to frame
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @return {(Buffer|String)[]} The framed data
       * @public
       */
      static frame(data, options) {
        let mask;
        let merge = false;
        let offset = 2;
        let skipMasking = false;
        if (options.mask) {
          mask = options.maskBuffer || maskBuffer;
          if (options.generateMask) {
            options.generateMask(mask);
          } else {
            if (randomPoolPointer === RANDOM_POOL_SIZE) {
              if (randomPool === void 0) {
                randomPool = Buffer.alloc(RANDOM_POOL_SIZE);
              }
              randomFillSync(randomPool, 0, RANDOM_POOL_SIZE);
              randomPoolPointer = 0;
            }
            mask[0] = randomPool[randomPoolPointer++];
            mask[1] = randomPool[randomPoolPointer++];
            mask[2] = randomPool[randomPoolPointer++];
            mask[3] = randomPool[randomPoolPointer++];
          }
          skipMasking = (mask[0] | mask[1] | mask[2] | mask[3]) === 0;
          offset = 6;
        }
        let dataLength;
        if (typeof data === "string") {
          if ((!options.mask || skipMasking) && options[kByteLength] !== void 0) {
            dataLength = options[kByteLength];
          } else {
            data = Buffer.from(data);
            dataLength = data.length;
          }
        } else {
          dataLength = data.length;
          merge = options.mask && options.readOnly && !skipMasking;
        }
        let payloadLength = dataLength;
        if (dataLength >= 65536) {
          offset += 8;
          payloadLength = 127;
        } else if (dataLength > 125) {
          offset += 2;
          payloadLength = 126;
        }
        const target = Buffer.allocUnsafe(merge ? dataLength + offset : offset);
        target[0] = options.fin ? options.opcode | 128 : options.opcode;
        if (options.rsv1) target[0] |= 64;
        target[1] = payloadLength;
        if (payloadLength === 126) {
          target.writeUInt16BE(dataLength, 2);
        } else if (payloadLength === 127) {
          target[2] = target[3] = 0;
          target.writeUIntBE(dataLength, 4, 6);
        }
        if (!options.mask) return [target, data];
        target[1] |= 128;
        target[offset - 4] = mask[0];
        target[offset - 3] = mask[1];
        target[offset - 2] = mask[2];
        target[offset - 1] = mask[3];
        if (skipMasking) return [target, data];
        if (merge) {
          applyMask(data, mask, target, offset, dataLength);
          return [target];
        }
        applyMask(data, mask, data, 0, dataLength);
        return [target, data];
      }
      /**
       * Sends a close message to the other peer.
       *
       * @param {Number} [code] The status code component of the body
       * @param {(String|Buffer)} [data] The message component of the body
       * @param {Boolean} [mask=false] Specifies whether or not to mask the message
       * @param {Function} [cb] Callback
       * @public
       */
      close(code, data, mask, cb) {
        let buf;
        if (code === void 0) {
          buf = EMPTY_BUFFER;
        } else if (typeof code !== "number" || !isValidStatusCode(code)) {
          throw new TypeError("First argument must be a valid error code number");
        } else if (data === void 0 || !data.length) {
          buf = Buffer.allocUnsafe(2);
          buf.writeUInt16BE(code, 0);
        } else {
          const length = Buffer.byteLength(data);
          if (length > 123) {
            throw new RangeError("The message must not be greater than 123 bytes");
          }
          buf = Buffer.allocUnsafe(2 + length);
          buf.writeUInt16BE(code, 0);
          if (typeof data === "string") {
            buf.write(data, 2);
          } else if (isUint8Array(data)) {
            buf.set(data, 2);
          } else {
            throw new TypeError("Second argument must be a string or a Uint8Array");
          }
        }
        const options = {
          [kByteLength]: buf.length,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 8,
          readOnly: false,
          rsv1: false
        };
        if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, buf, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(buf, options), cb);
        }
      }
      /**
       * Sends a ping message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Boolean} [mask=false] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback
       * @public
       */
      ping(data, mask, cb) {
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (byteLength > 125) {
          throw new RangeError("The data size must not be greater than 125 bytes");
        }
        const options = {
          [kByteLength]: byteLength,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 9,
          readOnly,
          rsv1: false
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, false, options, cb]);
          } else {
            this.getBlobData(data, false, options, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(data, options), cb);
        }
      }
      /**
       * Sends a pong message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Boolean} [mask=false] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback
       * @public
       */
      pong(data, mask, cb) {
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (byteLength > 125) {
          throw new RangeError("The data size must not be greater than 125 bytes");
        }
        const options = {
          [kByteLength]: byteLength,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 10,
          readOnly,
          rsv1: false
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, false, options, cb]);
          } else {
            this.getBlobData(data, false, options, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(data, options), cb);
        }
      }
      /**
       * Sends a data message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Object} options Options object
       * @param {Boolean} [options.binary=false] Specifies whether `data` is binary
       *     or text
       * @param {Boolean} [options.compress=false] Specifies whether or not to
       *     compress `data`
       * @param {Boolean} [options.fin=false] Specifies whether the fragment is the
       *     last one
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Function} [cb] Callback
       * @public
       */
      send(data, options, cb) {
        const perMessageDeflate = this._extensions[PerMessageDeflate2.extensionName];
        let opcode = options.binary ? 2 : 1;
        let rsv1 = options.compress;
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (this._firstFragment) {
          this._firstFragment = false;
          if (rsv1 && perMessageDeflate && perMessageDeflate.params[perMessageDeflate._isServer ? "server_no_context_takeover" : "client_no_context_takeover"]) {
            rsv1 = byteLength >= perMessageDeflate._threshold;
          }
          this._compress = rsv1;
        } else {
          rsv1 = false;
          opcode = 0;
        }
        if (options.fin) this._firstFragment = true;
        const opts = {
          [kByteLength]: byteLength,
          fin: options.fin,
          generateMask: this._generateMask,
          mask: options.mask,
          maskBuffer: this._maskBuffer,
          opcode,
          readOnly,
          rsv1
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, this._compress, opts, cb]);
          } else {
            this.getBlobData(data, this._compress, opts, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, this._compress, opts, cb]);
        } else {
          this.dispatch(data, this._compress, opts, cb);
        }
      }
      /**
       * Gets the contents of a blob as binary data.
       *
       * @param {Blob} blob The blob
       * @param {Boolean} [compress=false] Specifies whether or not to compress
       *     the data
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @param {Function} [cb] Callback
       * @private
       */
      getBlobData(blob, compress, options, cb) {
        this._bufferedBytes += options[kByteLength];
        this._state = GET_BLOB_DATA;
        blob.arrayBuffer().then((arrayBuffer) => {
          if (this._socket.destroyed) {
            const err = new Error(
              "The socket was closed while the blob was being read"
            );
            process.nextTick(callCallbacks, this, err, cb);
            return;
          }
          this._bufferedBytes -= options[kByteLength];
          const data = toBuffer(arrayBuffer);
          if (!compress) {
            this._state = DEFAULT;
            this.sendFrame(_Sender.frame(data, options), cb);
            this.dequeue();
          } else {
            this.dispatch(data, compress, options, cb);
          }
        }).catch((err) => {
          process.nextTick(onError, this, err, cb);
        });
      }
      /**
       * Dispatches a message.
       *
       * @param {(Buffer|String)} data The message to send
       * @param {Boolean} [compress=false] Specifies whether or not to compress
       *     `data`
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @param {Function} [cb] Callback
       * @private
       */
      dispatch(data, compress, options, cb) {
        if (!compress) {
          this.sendFrame(_Sender.frame(data, options), cb);
          return;
        }
        const perMessageDeflate = this._extensions[PerMessageDeflate2.extensionName];
        this._bufferedBytes += options[kByteLength];
        this._state = DEFLATING;
        perMessageDeflate.compress(data, options.fin, (_, buf) => {
          if (this._socket.destroyed) {
            const err = new Error(
              "The socket was closed while data was being compressed"
            );
            callCallbacks(this, err, cb);
            return;
          }
          this._bufferedBytes -= options[kByteLength];
          this._state = DEFAULT;
          options.readOnly = false;
          this.sendFrame(_Sender.frame(buf, options), cb);
          this.dequeue();
        });
      }
      /**
       * Executes queued send operations.
       *
       * @private
       */
      dequeue() {
        while (this._state === DEFAULT && this._queue.length) {
          const params = this._queue.shift();
          this._bufferedBytes -= params[3][kByteLength];
          Reflect.apply(params[0], this, params.slice(1));
        }
      }
      /**
       * Enqueues a send operation.
       *
       * @param {Array} params Send operation parameters.
       * @private
       */
      enqueue(params) {
        this._bufferedBytes += params[3][kByteLength];
        this._queue.push(params);
      }
      /**
       * Sends a frame.
       *
       * @param {(Buffer | String)[]} list The frame to send
       * @param {Function} [cb] Callback
       * @private
       */
      sendFrame(list, cb) {
        if (list.length === 2) {
          this._socket.cork();
          this._socket.write(list[0]);
          this._socket.write(list[1], cb);
          this._socket.uncork();
        } else {
          this._socket.write(list[0], cb);
        }
      }
    };
    module2.exports = Sender2;
    function callCallbacks(sender, err, cb) {
      if (typeof cb === "function") cb(err);
      for (let i = 0; i < sender._queue.length; i++) {
        const params = sender._queue[i];
        const callback = params[params.length - 1];
        if (typeof callback === "function") callback(err);
      }
    }
    function onError(sender, err, cb) {
      callCallbacks(sender, err, cb);
      sender.onerror(err);
    }
  }
});

// node_modules/ws/lib/event-target.js
var require_event_target = __commonJS({
  "node_modules/ws/lib/event-target.js"(exports2, module2) {
    "use strict";
    var { kForOnEventAttribute, kListener } = require_constants();
    var kCode = /* @__PURE__ */ Symbol("kCode");
    var kData = /* @__PURE__ */ Symbol("kData");
    var kError = /* @__PURE__ */ Symbol("kError");
    var kMessage = /* @__PURE__ */ Symbol("kMessage");
    var kReason = /* @__PURE__ */ Symbol("kReason");
    var kTarget = /* @__PURE__ */ Symbol("kTarget");
    var kType = /* @__PURE__ */ Symbol("kType");
    var kWasClean = /* @__PURE__ */ Symbol("kWasClean");
    var Event = class {
      /**
       * Create a new `Event`.
       *
       * @param {String} type The name of the event
       * @throws {TypeError} If the `type` argument is not specified
       */
      constructor(type) {
        this[kTarget] = null;
        this[kType] = type;
      }
      /**
       * @type {*}
       */
      get target() {
        return this[kTarget];
      }
      /**
       * @type {String}
       */
      get type() {
        return this[kType];
      }
    };
    Object.defineProperty(Event.prototype, "target", { enumerable: true });
    Object.defineProperty(Event.prototype, "type", { enumerable: true });
    var CloseEvent = class extends Event {
      /**
       * Create a new `CloseEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {Number} [options.code=0] The status code explaining why the
       *     connection was closed
       * @param {String} [options.reason=''] A human-readable string explaining why
       *     the connection was closed
       * @param {Boolean} [options.wasClean=false] Indicates whether or not the
       *     connection was cleanly closed
       */
      constructor(type, options = {}) {
        super(type);
        this[kCode] = options.code === void 0 ? 0 : options.code;
        this[kReason] = options.reason === void 0 ? "" : options.reason;
        this[kWasClean] = options.wasClean === void 0 ? false : options.wasClean;
      }
      /**
       * @type {Number}
       */
      get code() {
        return this[kCode];
      }
      /**
       * @type {String}
       */
      get reason() {
        return this[kReason];
      }
      /**
       * @type {Boolean}
       */
      get wasClean() {
        return this[kWasClean];
      }
    };
    Object.defineProperty(CloseEvent.prototype, "code", { enumerable: true });
    Object.defineProperty(CloseEvent.prototype, "reason", { enumerable: true });
    Object.defineProperty(CloseEvent.prototype, "wasClean", { enumerable: true });
    var ErrorEvent = class extends Event {
      /**
       * Create a new `ErrorEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {*} [options.error=null] The error that generated this event
       * @param {String} [options.message=''] The error message
       */
      constructor(type, options = {}) {
        super(type);
        this[kError] = options.error === void 0 ? null : options.error;
        this[kMessage] = options.message === void 0 ? "" : options.message;
      }
      /**
       * @type {*}
       */
      get error() {
        return this[kError];
      }
      /**
       * @type {String}
       */
      get message() {
        return this[kMessage];
      }
    };
    Object.defineProperty(ErrorEvent.prototype, "error", { enumerable: true });
    Object.defineProperty(ErrorEvent.prototype, "message", { enumerable: true });
    var MessageEvent = class extends Event {
      /**
       * Create a new `MessageEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {*} [options.data=null] The message content
       */
      constructor(type, options = {}) {
        super(type);
        this[kData] = options.data === void 0 ? null : options.data;
      }
      /**
       * @type {*}
       */
      get data() {
        return this[kData];
      }
    };
    Object.defineProperty(MessageEvent.prototype, "data", { enumerable: true });
    var EventTarget = {
      /**
       * Register an event listener.
       *
       * @param {String} type A string representing the event type to listen for
       * @param {(Function|Object)} handler The listener to add
       * @param {Object} [options] An options object specifies characteristics about
       *     the event listener
       * @param {Boolean} [options.once=false] A `Boolean` indicating that the
       *     listener should be invoked at most once after being added. If `true`,
       *     the listener would be automatically removed when invoked.
       * @public
       */
      addEventListener(type, handler, options = {}) {
        for (const listener of this.listeners(type)) {
          if (!options[kForOnEventAttribute] && listener[kListener] === handler && !listener[kForOnEventAttribute]) {
            return;
          }
        }
        let wrapper;
        if (type === "message") {
          wrapper = function onMessage(data, isBinary) {
            const event = new MessageEvent("message", {
              data: isBinary ? data : data.toString()
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "close") {
          wrapper = function onClose(code, message) {
            const event = new CloseEvent("close", {
              code,
              reason: message.toString(),
              wasClean: this._closeFrameReceived && this._closeFrameSent
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "error") {
          wrapper = function onError(error) {
            const event = new ErrorEvent("error", {
              error,
              message: error.message
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "open") {
          wrapper = function onOpen() {
            const event = new Event("open");
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else {
          return;
        }
        wrapper[kForOnEventAttribute] = !!options[kForOnEventAttribute];
        wrapper[kListener] = handler;
        if (options.once) {
          this.once(type, wrapper);
        } else {
          this.on(type, wrapper);
        }
      },
      /**
       * Remove an event listener.
       *
       * @param {String} type A string representing the event type to remove
       * @param {(Function|Object)} handler The listener to remove
       * @public
       */
      removeEventListener(type, handler) {
        for (const listener of this.listeners(type)) {
          if (listener[kListener] === handler && !listener[kForOnEventAttribute]) {
            this.removeListener(type, listener);
            break;
          }
        }
      }
    };
    module2.exports = {
      CloseEvent,
      ErrorEvent,
      Event,
      EventTarget,
      MessageEvent
    };
    function callListener(listener, thisArg, event) {
      if (typeof listener === "object" && listener.handleEvent) {
        listener.handleEvent.call(listener, event);
      } else {
        listener.call(thisArg, event);
      }
    }
  }
});

// node_modules/ws/lib/extension.js
var require_extension = __commonJS({
  "node_modules/ws/lib/extension.js"(exports2, module2) {
    "use strict";
    var { tokenChars } = require_validation();
    function push(dest, name, elem) {
      if (dest[name] === void 0) dest[name] = [elem];
      else dest[name].push(elem);
    }
    function parse(header) {
      const offers = /* @__PURE__ */ Object.create(null);
      let params = /* @__PURE__ */ Object.create(null);
      let mustUnescape = false;
      let isEscaping = false;
      let inQuotes = false;
      let extensionName;
      let paramName;
      let start = -1;
      let code = -1;
      let end = -1;
      let i = 0;
      for (; i < header.length; i++) {
        code = header.charCodeAt(i);
        if (extensionName === void 0) {
          if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (i !== 0 && (code === 32 || code === 9)) {
            if (end === -1 && start !== -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            const name = header.slice(start, end);
            if (code === 44) {
              push(offers, name, params);
              params = /* @__PURE__ */ Object.create(null);
            } else {
              extensionName = name;
            }
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        } else if (paramName === void 0) {
          if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (code === 32 || code === 9) {
            if (end === -1 && start !== -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            push(params, header.slice(start, end), true);
            if (code === 44) {
              push(offers, extensionName, params);
              params = /* @__PURE__ */ Object.create(null);
              extensionName = void 0;
            }
            start = end = -1;
          } else if (code === 61 && start !== -1 && end === -1) {
            paramName = header.slice(start, i);
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        } else {
          if (isEscaping) {
            if (tokenChars[code] !== 1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (start === -1) start = i;
            else if (!mustUnescape) mustUnescape = true;
            isEscaping = false;
          } else if (inQuotes) {
            if (tokenChars[code] === 1) {
              if (start === -1) start = i;
            } else if (code === 34 && start !== -1) {
              inQuotes = false;
              end = i;
            } else if (code === 92) {
              isEscaping = true;
            } else {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
          } else if (code === 34 && header.charCodeAt(i - 1) === 61) {
            inQuotes = true;
          } else if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (start !== -1 && (code === 32 || code === 9)) {
            if (end === -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            let value = header.slice(start, end);
            if (mustUnescape) {
              value = value.replace(/\\/g, "");
              mustUnescape = false;
            }
            push(params, paramName, value);
            if (code === 44) {
              push(offers, extensionName, params);
              params = /* @__PURE__ */ Object.create(null);
              extensionName = void 0;
            }
            paramName = void 0;
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        }
      }
      if (start === -1 || inQuotes || code === 32 || code === 9) {
        throw new SyntaxError("Unexpected end of input");
      }
      if (end === -1) end = i;
      const token = header.slice(start, end);
      if (extensionName === void 0) {
        push(offers, token, params);
      } else {
        if (paramName === void 0) {
          push(params, token, true);
        } else if (mustUnescape) {
          push(params, paramName, token.replace(/\\/g, ""));
        } else {
          push(params, paramName, token);
        }
        push(offers, extensionName, params);
      }
      return offers;
    }
    function format(extensions) {
      return Object.keys(extensions).map((extension2) => {
        let configurations = extensions[extension2];
        if (!Array.isArray(configurations)) configurations = [configurations];
        return configurations.map((params) => {
          return [extension2].concat(
            Object.keys(params).map((k) => {
              let values = params[k];
              if (!Array.isArray(values)) values = [values];
              return values.map((v) => v === true ? k : `${k}=${v}`).join("; ");
            })
          ).join("; ");
        }).join(", ");
      }).join(", ");
    }
    module2.exports = { format, parse };
  }
});

// node_modules/ws/lib/websocket.js
var require_websocket = __commonJS({
  "node_modules/ws/lib/websocket.js"(exports2, module2) {
    "use strict";
    var EventEmitter = require("events");
    var https = require("https");
    var http = require("http");
    var net = require("net");
    var tls = require("tls");
    var { randomBytes: randomBytes2, createHash } = require("crypto");
    var { Duplex, Readable } = require("stream");
    var { URL: URL2 } = require("url");
    var PerMessageDeflate2 = require_permessage_deflate();
    var Receiver2 = require_receiver();
    var Sender2 = require_sender();
    var { isBlob } = require_validation();
    var {
      BINARY_TYPES,
      CLOSE_TIMEOUT,
      EMPTY_BUFFER,
      GUID,
      kForOnEventAttribute,
      kListener,
      kStatusCode,
      kWebSocket,
      NOOP
    } = require_constants();
    var {
      EventTarget: { addEventListener, removeEventListener }
    } = require_event_target();
    var { format, parse } = require_extension();
    var { toBuffer } = require_buffer_util();
    var kAborted = /* @__PURE__ */ Symbol("kAborted");
    var protocolVersions = [8, 13];
    var readyStates = ["CONNECTING", "OPEN", "CLOSING", "CLOSED"];
    var subprotocolRegex = /^[!#$%&'*+\-.0-9A-Z^_`|a-z~]+$/;
    var WebSocket2 = class _WebSocket extends EventEmitter {
      /**
       * Create a new `WebSocket`.
       *
       * @param {(String|URL)} address The URL to which to connect
       * @param {(String|String[])} [protocols] The subprotocols
       * @param {Object} [options] Connection options
       */
      constructor(address, protocols, options) {
        super();
        this._binaryType = BINARY_TYPES[0];
        this._closeCode = 1006;
        this._closeFrameReceived = false;
        this._closeFrameSent = false;
        this._closeMessage = EMPTY_BUFFER;
        this._closeTimer = null;
        this._errorEmitted = false;
        this._extensions = {};
        this._paused = false;
        this._protocol = "";
        this._readyState = _WebSocket.CONNECTING;
        this._receiver = null;
        this._sender = null;
        this._socket = null;
        if (address !== null) {
          this._bufferedAmount = 0;
          this._isServer = false;
          this._redirects = 0;
          if (protocols === void 0) {
            if (!options || options.protocols === void 0) {
              protocols = [];
            } else if (Array.isArray(options.protocols)) {
              protocols = options.protocols;
            } else {
              protocols = [options.protocols];
            }
          } else if (!Array.isArray(protocols)) {
            if (typeof protocols === "object" && protocols !== null) {
              options = protocols;
              if (options.protocols === void 0) {
                protocols = [];
              } else if (Array.isArray(options.protocols)) {
                protocols = options.protocols;
              } else {
                protocols = [options.protocols];
              }
            } else {
              protocols = [protocols];
            }
          }
          initAsClient(this, address, protocols, options);
        } else {
          this._autoPong = options.autoPong;
          this._closeTimeout = options.closeTimeout;
          this._isServer = true;
        }
      }
      /**
       * For historical reasons, the custom "nodebuffer" type is used by the default
       * instead of "blob".
       *
       * @type {String}
       */
      get binaryType() {
        return this._binaryType;
      }
      set binaryType(type) {
        if (!BINARY_TYPES.includes(type)) return;
        this._binaryType = type;
        if (this._receiver) this._receiver._binaryType = type;
      }
      /**
       * @type {Number}
       */
      get bufferedAmount() {
        if (!this._socket) return this._bufferedAmount;
        return this._socket._writableState.length + this._sender._bufferedBytes;
      }
      /**
       * @type {String}
       */
      get extensions() {
        return Object.keys(this._extensions).join();
      }
      /**
       * @type {Boolean}
       */
      get isPaused() {
        return this._paused;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onclose() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onerror() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onopen() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onmessage() {
        return null;
      }
      /**
       * @type {String}
       */
      get protocol() {
        return this._protocol;
      }
      /**
       * @type {Number}
       */
      get readyState() {
        return this._readyState;
      }
      /**
       * @type {String}
       */
      get url() {
        return this._url;
      }
      /**
       * Set up the socket and the internal resources.
       *
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Object} options Options object
       * @param {Boolean} [options.allowSynchronousEvents=false] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Number} [options.maxBufferedChunks=0] The maximum number of
       *     buffered data chunks
       * @param {Number} [options.maxFragments=0] The maximum number of message
       *     fragments
       * @param {Number} [options.maxPayload=0] The maximum allowed message size
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       * @private
       */
      setSocket(socket, head, options) {
        const receiver = new Receiver2({
          allowSynchronousEvents: options.allowSynchronousEvents,
          binaryType: this.binaryType,
          extensions: this._extensions,
          isServer: this._isServer,
          maxBufferedChunks: options.maxBufferedChunks,
          maxFragments: options.maxFragments,
          maxPayload: options.maxPayload,
          skipUTF8Validation: options.skipUTF8Validation
        });
        const sender = new Sender2(socket, this._extensions, options.generateMask);
        this._receiver = receiver;
        this._sender = sender;
        this._socket = socket;
        receiver[kWebSocket] = this;
        sender[kWebSocket] = this;
        socket[kWebSocket] = this;
        receiver.on("conclude", receiverOnConclude);
        receiver.on("drain", receiverOnDrain);
        receiver.on("error", receiverOnError);
        receiver.on("message", receiverOnMessage);
        receiver.on("ping", receiverOnPing);
        receiver.on("pong", receiverOnPong);
        sender.onerror = senderOnError;
        if (socket.setTimeout) socket.setTimeout(0);
        if (socket.setNoDelay) socket.setNoDelay();
        if (head.length > 0) socket.unshift(head);
        socket.on("close", socketOnClose);
        socket.on("data", socketOnData);
        socket.on("end", socketOnEnd);
        socket.on("error", socketOnError);
        this._readyState = _WebSocket.OPEN;
        this.emit("open");
      }
      /**
       * Emit the `'close'` event.
       *
       * @private
       */
      emitClose() {
        if (!this._socket) {
          this._readyState = _WebSocket.CLOSED;
          this.emit("close", this._closeCode, this._closeMessage);
          return;
        }
        if (this._extensions[PerMessageDeflate2.extensionName]) {
          this._extensions[PerMessageDeflate2.extensionName].cleanup();
        }
        this._receiver.removeAllListeners();
        this._readyState = _WebSocket.CLOSED;
        this.emit("close", this._closeCode, this._closeMessage);
      }
      /**
       * Start a closing handshake.
       *
       *          +----------+   +-----------+   +----------+
       *     - - -|ws.close()|-->|close frame|-->|ws.close()|- - -
       *    |     +----------+   +-----------+   +----------+     |
       *          +----------+   +-----------+         |
       * CLOSING  |ws.close()|<--|close frame|<--+-----+       CLOSING
       *          +----------+   +-----------+   |
       *    |           |                        |   +---+        |
       *                +------------------------+-->|fin| - - - -
       *    |         +---+                      |   +---+
       *     - - - - -|fin|<---------------------+
       *              +---+
       *
       * @param {Number} [code] Status code explaining why the connection is closing
       * @param {(String|Buffer)} [data] The reason why the connection is
       *     closing
       * @public
       */
      close(code, data) {
        if (this.readyState === _WebSocket.CLOSED) return;
        if (this.readyState === _WebSocket.CONNECTING) {
          const msg = "WebSocket was closed before the connection was established";
          abortHandshake(this, this._req, msg);
          return;
        }
        if (this.readyState === _WebSocket.CLOSING) {
          if (this._closeFrameSent && (this._closeFrameReceived || this._receiver._writableState.errorEmitted)) {
            this._socket.end();
          }
          return;
        }
        this._sender.close(code, data, !this._isServer, (err) => {
          if (err) return;
          this._closeFrameSent = true;
          if (this._closeFrameReceived || this._receiver._writableState.errorEmitted) {
            this._socket.end();
          }
        });
        this._readyState = _WebSocket.CLOSING;
        setCloseTimer(this);
      }
      /**
       * Pause the socket.
       *
       * @public
       */
      pause() {
        if (this.readyState === _WebSocket.CONNECTING || this.readyState === _WebSocket.CLOSED) {
          return;
        }
        this._paused = true;
        this._socket.pause();
      }
      /**
       * Send a ping.
       *
       * @param {*} [data] The data to send
       * @param {Boolean} [mask] Indicates whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when the ping is sent
       * @public
       */
      ping(data, mask, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof data === "function") {
          cb = data;
          data = mask = void 0;
        } else if (typeof mask === "function") {
          cb = mask;
          mask = void 0;
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        if (mask === void 0) mask = !this._isServer;
        this._sender.ping(data || EMPTY_BUFFER, mask, cb);
      }
      /**
       * Send a pong.
       *
       * @param {*} [data] The data to send
       * @param {Boolean} [mask] Indicates whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when the pong is sent
       * @public
       */
      pong(data, mask, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof data === "function") {
          cb = data;
          data = mask = void 0;
        } else if (typeof mask === "function") {
          cb = mask;
          mask = void 0;
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        if (mask === void 0) mask = !this._isServer;
        this._sender.pong(data || EMPTY_BUFFER, mask, cb);
      }
      /**
       * Resume the socket.
       *
       * @public
       */
      resume() {
        if (this.readyState === _WebSocket.CONNECTING || this.readyState === _WebSocket.CLOSED) {
          return;
        }
        this._paused = false;
        if (!this._receiver._writableState.needDrain) this._socket.resume();
      }
      /**
       * Send a data message.
       *
       * @param {*} data The message to send
       * @param {Object} [options] Options object
       * @param {Boolean} [options.binary] Specifies whether `data` is binary or
       *     text
       * @param {Boolean} [options.compress] Specifies whether or not to compress
       *     `data`
       * @param {Boolean} [options.fin=true] Specifies whether the fragment is the
       *     last one
       * @param {Boolean} [options.mask] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when data is written out
       * @public
       */
      send(data, options, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof options === "function") {
          cb = options;
          options = {};
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        const opts = {
          binary: typeof data !== "string",
          mask: !this._isServer,
          compress: true,
          fin: true,
          ...options
        };
        if (!this._extensions[PerMessageDeflate2.extensionName]) {
          opts.compress = false;
        }
        this._sender.send(data || EMPTY_BUFFER, opts, cb);
      }
      /**
       * Forcibly close the connection.
       *
       * @public
       */
      terminate() {
        if (this.readyState === _WebSocket.CLOSED) return;
        if (this.readyState === _WebSocket.CONNECTING) {
          const msg = "WebSocket was closed before the connection was established";
          abortHandshake(this, this._req, msg);
          return;
        }
        if (this._socket) {
          this._readyState = _WebSocket.CLOSING;
          this._socket.destroy();
        }
      }
    };
    Object.defineProperty(WebSocket2, "CONNECTING", {
      enumerable: true,
      value: readyStates.indexOf("CONNECTING")
    });
    Object.defineProperty(WebSocket2.prototype, "CONNECTING", {
      enumerable: true,
      value: readyStates.indexOf("CONNECTING")
    });
    Object.defineProperty(WebSocket2, "OPEN", {
      enumerable: true,
      value: readyStates.indexOf("OPEN")
    });
    Object.defineProperty(WebSocket2.prototype, "OPEN", {
      enumerable: true,
      value: readyStates.indexOf("OPEN")
    });
    Object.defineProperty(WebSocket2, "CLOSING", {
      enumerable: true,
      value: readyStates.indexOf("CLOSING")
    });
    Object.defineProperty(WebSocket2.prototype, "CLOSING", {
      enumerable: true,
      value: readyStates.indexOf("CLOSING")
    });
    Object.defineProperty(WebSocket2, "CLOSED", {
      enumerable: true,
      value: readyStates.indexOf("CLOSED")
    });
    Object.defineProperty(WebSocket2.prototype, "CLOSED", {
      enumerable: true,
      value: readyStates.indexOf("CLOSED")
    });
    [
      "binaryType",
      "bufferedAmount",
      "extensions",
      "isPaused",
      "protocol",
      "readyState",
      "url"
    ].forEach((property) => {
      Object.defineProperty(WebSocket2.prototype, property, { enumerable: true });
    });
    ["open", "error", "close", "message"].forEach((method) => {
      Object.defineProperty(WebSocket2.prototype, `on${method}`, {
        enumerable: true,
        get() {
          for (const listener of this.listeners(method)) {
            if (listener[kForOnEventAttribute]) return listener[kListener];
          }
          return null;
        },
        set(handler) {
          for (const listener of this.listeners(method)) {
            if (listener[kForOnEventAttribute]) {
              this.removeListener(method, listener);
              break;
            }
          }
          if (typeof handler !== "function") return;
          this.addEventListener(method, handler, {
            [kForOnEventAttribute]: true
          });
        }
      });
    });
    WebSocket2.prototype.addEventListener = addEventListener;
    WebSocket2.prototype.removeEventListener = removeEventListener;
    module2.exports = WebSocket2;
    function initAsClient(websocket, address, protocols, options) {
      const opts = {
        allowSynchronousEvents: true,
        autoPong: true,
        closeTimeout: CLOSE_TIMEOUT,
        protocolVersion: protocolVersions[1],
        maxBufferedChunks: 256 * 1024,
        maxFragments: 16 * 1024,
        maxPayload: 100 * 1024 * 1024,
        skipUTF8Validation: false,
        perMessageDeflate: true,
        followRedirects: false,
        maxRedirects: 10,
        ...options,
        socketPath: void 0,
        hostname: void 0,
        protocol: void 0,
        protocols: void 0,
        timeout: void 0,
        method: "GET",
        host: void 0,
        path: void 0,
        port: void 0
      };
      websocket._autoPong = opts.autoPong;
      websocket._closeTimeout = opts.closeTimeout;
      if (!protocolVersions.includes(opts.protocolVersion)) {
        throw new RangeError(
          `Unsupported protocol version: ${opts.protocolVersion} (supported versions: ${protocolVersions.join(", ")})`
        );
      }
      let parsedUrl;
      if (address instanceof URL2) {
        parsedUrl = address;
      } else {
        try {
          parsedUrl = new URL2(address);
        } catch {
          throw new SyntaxError(`Invalid URL: ${address}`);
        }
      }
      if (parsedUrl.protocol === "http:") {
        parsedUrl.protocol = "ws:";
      } else if (parsedUrl.protocol === "https:") {
        parsedUrl.protocol = "wss:";
      }
      websocket._url = parsedUrl.href;
      const isSecure = parsedUrl.protocol === "wss:";
      const isIpcUrl = parsedUrl.protocol === "ws+unix:";
      let invalidUrlMessage;
      if (parsedUrl.protocol !== "ws:" && !isSecure && !isIpcUrl) {
        invalidUrlMessage = `The URL's protocol must be one of "ws:", "wss:", "http:", "https:", or "ws+unix:"`;
      } else if (isIpcUrl && !parsedUrl.pathname) {
        invalidUrlMessage = "The URL's pathname is empty";
      } else if (parsedUrl.hash) {
        invalidUrlMessage = "The URL contains a fragment identifier";
      }
      if (invalidUrlMessage) {
        const err = new SyntaxError(invalidUrlMessage);
        if (websocket._redirects === 0) {
          throw err;
        } else {
          emitErrorAndClose(websocket, err);
          return;
        }
      }
      const defaultPort = isSecure ? 443 : 80;
      const key = randomBytes2(16).toString("base64");
      const request = isSecure ? https.request : http.request;
      const protocolSet = /* @__PURE__ */ new Set();
      let perMessageDeflate;
      opts.createConnection = opts.createConnection || (isSecure ? tlsConnect : netConnect);
      opts.defaultPort = opts.defaultPort || defaultPort;
      opts.port = parsedUrl.port || defaultPort;
      opts.host = parsedUrl.hostname.startsWith("[") ? parsedUrl.hostname.slice(1, -1) : parsedUrl.hostname;
      opts.headers = {
        ...opts.headers,
        "Sec-WebSocket-Version": opts.protocolVersion,
        "Sec-WebSocket-Key": key,
        Connection: "Upgrade",
        Upgrade: "websocket"
      };
      opts.path = parsedUrl.pathname + parsedUrl.search;
      opts.timeout = opts.handshakeTimeout;
      if (opts.perMessageDeflate) {
        perMessageDeflate = new PerMessageDeflate2({
          ...opts.perMessageDeflate,
          isServer: false,
          maxPayload: opts.maxPayload
        });
        opts.headers["Sec-WebSocket-Extensions"] = format({
          [PerMessageDeflate2.extensionName]: perMessageDeflate.offer()
        });
      }
      if (protocols.length) {
        for (const protocol of protocols) {
          if (typeof protocol !== "string" || !subprotocolRegex.test(protocol) || protocolSet.has(protocol)) {
            throw new SyntaxError(
              "An invalid or duplicated subprotocol was specified"
            );
          }
          protocolSet.add(protocol);
        }
        opts.headers["Sec-WebSocket-Protocol"] = protocols.join(",");
      }
      if (opts.origin) {
        if (opts.protocolVersion < 13) {
          opts.headers["Sec-WebSocket-Origin"] = opts.origin;
        } else {
          opts.headers.Origin = opts.origin;
        }
      }
      if (parsedUrl.username || parsedUrl.password) {
        opts.auth = `${parsedUrl.username}:${parsedUrl.password}`;
      }
      if (isIpcUrl) {
        const parts = opts.path.split(":");
        opts.socketPath = parts[0];
        opts.path = parts[1];
      }
      let req;
      if (opts.followRedirects) {
        if (websocket._redirects === 0) {
          websocket._originalIpc = isIpcUrl;
          websocket._originalSecure = isSecure;
          websocket._originalHostOrSocketPath = isIpcUrl ? opts.socketPath : parsedUrl.host;
          const headers = options && options.headers;
          options = { ...options, headers: {} };
          if (headers) {
            for (const [key2, value] of Object.entries(headers)) {
              options.headers[key2.toLowerCase()] = value;
            }
          }
        } else if (websocket.listenerCount("redirect") === 0) {
          const isSameHost = isIpcUrl ? websocket._originalIpc ? opts.socketPath === websocket._originalHostOrSocketPath : false : websocket._originalIpc ? false : parsedUrl.host === websocket._originalHostOrSocketPath;
          if (!isSameHost || websocket._originalSecure && !isSecure) {
            delete opts.headers.authorization;
            delete opts.headers.cookie;
            if (!isSameHost) delete opts.headers.host;
            opts.auth = void 0;
          }
        }
        if (opts.auth && !options.headers.authorization) {
          options.headers.authorization = "Basic " + Buffer.from(opts.auth).toString("base64");
        }
        req = websocket._req = request(opts);
        if (websocket._redirects) {
          websocket.emit("redirect", websocket.url, req);
        }
      } else {
        req = websocket._req = request(opts);
      }
      if (opts.timeout) {
        req.on("timeout", () => {
          abortHandshake(websocket, req, "Opening handshake has timed out");
        });
      }
      req.on("error", (err) => {
        if (req === null || req[kAborted]) return;
        req = websocket._req = null;
        emitErrorAndClose(websocket, err);
      });
      req.on("response", (res) => {
        const location = res.headers.location;
        const statusCode = res.statusCode;
        if (location && opts.followRedirects && statusCode >= 300 && statusCode < 400) {
          if (++websocket._redirects > opts.maxRedirects) {
            abortHandshake(websocket, req, "Maximum redirects exceeded");
            return;
          }
          req.abort();
          let addr;
          try {
            addr = new URL2(location, address);
          } catch (e) {
            const err = new SyntaxError(`Invalid URL: ${location}`);
            emitErrorAndClose(websocket, err);
            return;
          }
          initAsClient(websocket, addr, protocols, options);
        } else if (!websocket.emit("unexpected-response", req, res)) {
          abortHandshake(
            websocket,
            req,
            `Unexpected server response: ${res.statusCode}`
          );
        }
      });
      req.on("upgrade", (res, socket, head) => {
        websocket.emit("upgrade", res);
        if (websocket.readyState !== WebSocket2.CONNECTING) return;
        req = websocket._req = null;
        const upgrade = res.headers.upgrade;
        if (upgrade === void 0 || upgrade.toLowerCase() !== "websocket") {
          abortHandshake(websocket, socket, "Invalid Upgrade header");
          return;
        }
        const digest = createHash("sha1").update(key + GUID).digest("base64");
        if (res.headers["sec-websocket-accept"] !== digest) {
          abortHandshake(websocket, socket, "Invalid Sec-WebSocket-Accept header");
          return;
        }
        const serverProt = res.headers["sec-websocket-protocol"];
        let protError;
        if (serverProt !== void 0) {
          if (!protocolSet.size) {
            protError = "Server sent a subprotocol but none was requested";
          } else if (!protocolSet.has(serverProt)) {
            protError = "Server sent an invalid subprotocol";
          }
        } else if (protocolSet.size) {
          protError = "Server sent no subprotocol";
        }
        if (protError) {
          abortHandshake(websocket, socket, protError);
          return;
        }
        if (serverProt) websocket._protocol = serverProt;
        const secWebSocketExtensions = res.headers["sec-websocket-extensions"];
        if (secWebSocketExtensions !== void 0) {
          if (!perMessageDeflate) {
            const message = "Server sent a Sec-WebSocket-Extensions header but no extension was requested";
            abortHandshake(websocket, socket, message);
            return;
          }
          let extensions;
          try {
            extensions = parse(secWebSocketExtensions);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Extensions header";
            abortHandshake(websocket, socket, message);
            return;
          }
          const extensionNames = Object.keys(extensions);
          if (extensionNames.length !== 1 || extensionNames[0] !== PerMessageDeflate2.extensionName) {
            const message = "Server indicated an extension that was not requested";
            abortHandshake(websocket, socket, message);
            return;
          }
          try {
            perMessageDeflate.accept(extensions[PerMessageDeflate2.extensionName]);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Extensions header";
            abortHandshake(websocket, socket, message);
            return;
          }
          websocket._extensions[PerMessageDeflate2.extensionName] = perMessageDeflate;
        }
        websocket.setSocket(socket, head, {
          allowSynchronousEvents: opts.allowSynchronousEvents,
          generateMask: opts.generateMask,
          maxBufferedChunks: opts.maxBufferedChunks,
          maxFragments: opts.maxFragments,
          maxPayload: opts.maxPayload,
          skipUTF8Validation: opts.skipUTF8Validation
        });
      });
      if (opts.finishRequest) {
        opts.finishRequest(req, websocket);
      } else {
        req.end();
      }
    }
    function emitErrorAndClose(websocket, err) {
      websocket._readyState = WebSocket2.CLOSING;
      websocket._errorEmitted = true;
      websocket.emit("error", err);
      websocket.emitClose();
    }
    function netConnect(options) {
      options.path = options.socketPath;
      return net.connect(options);
    }
    function tlsConnect(options) {
      options.path = void 0;
      if (!options.servername && options.servername !== "") {
        options.servername = net.isIP(options.host) ? "" : options.host;
      }
      return tls.connect(options);
    }
    function abortHandshake(websocket, stream, message) {
      websocket._readyState = WebSocket2.CLOSING;
      const err = new Error(message);
      Error.captureStackTrace(err, abortHandshake);
      if (stream.setHeader) {
        stream[kAborted] = true;
        stream.abort();
        if (stream.socket && !stream.socket.destroyed) {
          stream.socket.destroy();
        }
        process.nextTick(emitErrorAndClose, websocket, err);
      } else {
        stream.destroy(err);
        stream.once("error", websocket.emit.bind(websocket, "error"));
        stream.once("close", websocket.emitClose.bind(websocket));
      }
    }
    function sendAfterClose(websocket, data, cb) {
      if (data) {
        const length = isBlob(data) ? data.size : toBuffer(data).length;
        if (websocket._socket) websocket._sender._bufferedBytes += length;
        else websocket._bufferedAmount += length;
      }
      if (cb) {
        const err = new Error(
          `WebSocket is not open: readyState ${websocket.readyState} (${readyStates[websocket.readyState]})`
        );
        process.nextTick(cb, err);
      }
    }
    function receiverOnConclude(code, reason) {
      const websocket = this[kWebSocket];
      websocket._closeFrameReceived = true;
      websocket._closeMessage = reason;
      websocket._closeCode = code;
      if (websocket._socket[kWebSocket] === void 0) return;
      websocket._socket.removeListener("data", socketOnData);
      process.nextTick(resume, websocket._socket);
      if (code === 1005) websocket.close();
      else websocket.close(code, reason);
    }
    function receiverOnDrain() {
      const websocket = this[kWebSocket];
      if (!websocket.isPaused) websocket._socket.resume();
    }
    function receiverOnError(err) {
      const websocket = this[kWebSocket];
      if (websocket._socket[kWebSocket] !== void 0) {
        websocket._socket.removeListener("data", socketOnData);
        process.nextTick(resume, websocket._socket);
        websocket.close(err[kStatusCode]);
      }
      if (!websocket._errorEmitted) {
        websocket._errorEmitted = true;
        websocket.emit("error", err);
      }
    }
    function receiverOnFinish() {
      this[kWebSocket].emitClose();
    }
    function receiverOnMessage(data, isBinary) {
      this[kWebSocket].emit("message", data, isBinary);
    }
    function receiverOnPing(data) {
      const websocket = this[kWebSocket];
      if (websocket._autoPong) websocket.pong(data, !this._isServer, NOOP);
      websocket.emit("ping", data);
    }
    function receiverOnPong(data) {
      this[kWebSocket].emit("pong", data);
    }
    function resume(stream) {
      stream.resume();
    }
    function senderOnError(err) {
      const websocket = this[kWebSocket];
      if (websocket.readyState === WebSocket2.CLOSED) return;
      if (websocket.readyState === WebSocket2.OPEN) {
        websocket._readyState = WebSocket2.CLOSING;
        setCloseTimer(websocket);
      }
      this._socket.end();
      if (!websocket._errorEmitted) {
        websocket._errorEmitted = true;
        websocket.emit("error", err);
      }
    }
    function setCloseTimer(websocket) {
      websocket._closeTimer = setTimeout(
        websocket._socket.destroy.bind(websocket._socket),
        websocket._closeTimeout
      );
    }
    function socketOnClose() {
      const websocket = this[kWebSocket];
      this.removeListener("close", socketOnClose);
      this.removeListener("data", socketOnData);
      this.removeListener("end", socketOnEnd);
      websocket._readyState = WebSocket2.CLOSING;
      if (!this._readableState.endEmitted && !websocket._closeFrameReceived && !websocket._receiver._writableState.errorEmitted && this._readableState.length !== 0) {
        const chunk = this.read(this._readableState.length);
        websocket._receiver.write(chunk);
      }
      websocket._receiver.end();
      this[kWebSocket] = void 0;
      clearTimeout(websocket._closeTimer);
      if (websocket._receiver._writableState.finished || websocket._receiver._writableState.errorEmitted) {
        websocket.emitClose();
      } else {
        websocket._receiver.on("error", receiverOnFinish);
        websocket._receiver.on("finish", receiverOnFinish);
      }
    }
    function socketOnData(chunk) {
      if (!this[kWebSocket]._receiver.write(chunk)) {
        this.pause();
      }
    }
    function socketOnEnd() {
      const websocket = this[kWebSocket];
      websocket._readyState = WebSocket2.CLOSING;
      websocket._receiver.end();
      this.end();
    }
    function socketOnError() {
      const websocket = this[kWebSocket];
      this.removeListener("error", socketOnError);
      this.on("error", NOOP);
      if (websocket) {
        websocket._readyState = WebSocket2.CLOSING;
        this.destroy();
      }
    }
  }
});

// node_modules/ws/lib/stream.js
var require_stream = __commonJS({
  "node_modules/ws/lib/stream.js"(exports2, module2) {
    "use strict";
    var WebSocket2 = require_websocket();
    var { Duplex } = require("stream");
    function emitClose(stream) {
      stream.emit("close");
    }
    function duplexOnEnd() {
      if (!this.destroyed && this._writableState.finished) {
        this.destroy();
      }
    }
    function duplexOnError(err) {
      this.removeListener("error", duplexOnError);
      this.destroy();
      if (this.listenerCount("error") === 0) {
        this.emit("error", err);
      }
    }
    function createWebSocketStream2(ws, options) {
      let terminateOnDestroy = true;
      const duplex = new Duplex({
        ...options,
        autoDestroy: false,
        emitClose: false,
        objectMode: false,
        writableObjectMode: false
      });
      ws.on("message", function message(msg, isBinary) {
        const data = !isBinary && duplex._readableState.objectMode ? msg.toString() : msg;
        if (!duplex.push(data)) ws.pause();
      });
      ws.once("error", function error(err) {
        if (duplex.destroyed) return;
        terminateOnDestroy = false;
        duplex.destroy(err);
      });
      ws.once("close", function close() {
        if (duplex.destroyed) return;
        duplex.push(null);
      });
      duplex._destroy = function(err, callback) {
        if (ws.readyState === ws.CLOSED) {
          callback(err);
          process.nextTick(emitClose, duplex);
          return;
        }
        let called = false;
        ws.once("error", function error(err2) {
          called = true;
          callback(err2);
        });
        ws.once("close", function close() {
          if (!called) callback(err);
          process.nextTick(emitClose, duplex);
        });
        if (terminateOnDestroy) ws.terminate();
      };
      duplex._final = function(callback) {
        if (ws.readyState === ws.CONNECTING) {
          ws.once("open", function open() {
            duplex._final(callback);
          });
          return;
        }
        if (ws._socket === null) return;
        if (ws._socket._writableState.finished) {
          callback();
          if (duplex._readableState.endEmitted) duplex.destroy();
        } else {
          ws._socket.once("finish", function finish() {
            callback();
          });
          ws.close();
        }
      };
      duplex._read = function() {
        if (ws.isPaused) ws.resume();
      };
      duplex._write = function(chunk, encoding, callback) {
        if (ws.readyState === ws.CONNECTING) {
          ws.once("open", function open() {
            duplex._write(chunk, encoding, callback);
          });
          return;
        }
        ws.send(chunk, callback);
      };
      duplex.on("end", duplexOnEnd);
      duplex.on("error", duplexOnError);
      return duplex;
    }
    module2.exports = createWebSocketStream2;
  }
});

// node_modules/ws/lib/subprotocol.js
var require_subprotocol = __commonJS({
  "node_modules/ws/lib/subprotocol.js"(exports2, module2) {
    "use strict";
    var { tokenChars } = require_validation();
    function parse(header) {
      const protocols = /* @__PURE__ */ new Set();
      let start = -1;
      let end = -1;
      let i = 0;
      for (i; i < header.length; i++) {
        const code = header.charCodeAt(i);
        if (end === -1 && tokenChars[code] === 1) {
          if (start === -1) start = i;
        } else if (i !== 0 && (code === 32 || code === 9)) {
          if (end === -1 && start !== -1) end = i;
        } else if (code === 44) {
          if (start === -1) {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
          if (end === -1) end = i;
          const protocol2 = header.slice(start, end);
          if (protocols.has(protocol2)) {
            throw new SyntaxError(`The "${protocol2}" subprotocol is duplicated`);
          }
          protocols.add(protocol2);
          start = end = -1;
        } else {
          throw new SyntaxError(`Unexpected character at index ${i}`);
        }
      }
      if (start === -1 || end !== -1) {
        throw new SyntaxError("Unexpected end of input");
      }
      const protocol = header.slice(start, i);
      if (protocols.has(protocol)) {
        throw new SyntaxError(`The "${protocol}" subprotocol is duplicated`);
      }
      protocols.add(protocol);
      return protocols;
    }
    module2.exports = { parse };
  }
});

// node_modules/ws/lib/websocket-server.js
var require_websocket_server = __commonJS({
  "node_modules/ws/lib/websocket-server.js"(exports2, module2) {
    "use strict";
    var EventEmitter = require("events");
    var http = require("http");
    var { Duplex } = require("stream");
    var { createHash } = require("crypto");
    var extension2 = require_extension();
    var PerMessageDeflate2 = require_permessage_deflate();
    var subprotocol2 = require_subprotocol();
    var WebSocket2 = require_websocket();
    var { CLOSE_TIMEOUT, GUID, kWebSocket } = require_constants();
    var keyRegex = /^[+/0-9A-Za-z]{22}==$/;
    var RUNNING = 0;
    var CLOSING = 1;
    var CLOSED = 2;
    var WebSocketServer2 = class extends EventEmitter {
      /**
       * Create a `WebSocketServer` instance.
       *
       * @param {Object} options Configuration options
       * @param {Boolean} [options.allowSynchronousEvents=true] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {Boolean} [options.autoPong=true] Specifies whether or not to
       *     automatically send a pong in response to a ping
       * @param {Number} [options.backlog=511] The maximum length of the queue of
       *     pending connections
       * @param {Boolean} [options.clientTracking=true] Specifies whether or not to
       *     track clients
       * @param {Number} [options.closeTimeout=30000] Duration in milliseconds to
       *     wait for the closing handshake to finish after `websocket.close()` is
       *     called
       * @param {Function} [options.handleProtocols] A hook to handle protocols
       * @param {String} [options.host] The hostname where to bind the server
       * @param {Number} [options.maxBufferedChunks=262144] The maximum number of
       *     buffered data chunks
       * @param {Number} [options.maxFragments=16384] The maximum number of message
       *     fragments
       * @param {Number} [options.maxPayload=104857600] The maximum allowed message
       *     size
       * @param {Boolean} [options.noServer=false] Enable no server mode
       * @param {String} [options.path] Accept only connections matching this path
       * @param {(Boolean|Object)} [options.perMessageDeflate=false] Enable/disable
       *     permessage-deflate
       * @param {Number} [options.port] The port where to bind the server
       * @param {(http.Server|https.Server)} [options.server] A pre-created HTTP/S
       *     server to use
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       * @param {Function} [options.verifyClient] A hook to reject connections
       * @param {Function} [options.WebSocket=WebSocket] Specifies the `WebSocket`
       *     class to use. It must be the `WebSocket` class or class that extends it
       * @param {Function} [callback] A listener for the `listening` event
       */
      constructor(options, callback) {
        super();
        options = {
          allowSynchronousEvents: true,
          autoPong: true,
          maxBufferedChunks: 256 * 1024,
          maxFragments: 16 * 1024,
          maxPayload: 100 * 1024 * 1024,
          skipUTF8Validation: false,
          perMessageDeflate: false,
          handleProtocols: null,
          clientTracking: true,
          closeTimeout: CLOSE_TIMEOUT,
          verifyClient: null,
          noServer: false,
          backlog: null,
          // use default (511 as implemented in net.js)
          server: null,
          host: null,
          path: null,
          port: null,
          WebSocket: WebSocket2,
          ...options
        };
        if (options.port == null && !options.server && !options.noServer || options.port != null && (options.server || options.noServer) || options.server && options.noServer) {
          throw new TypeError(
            'One and only one of the "port", "server", or "noServer" options must be specified'
          );
        }
        if (options.port != null) {
          this._server = http.createServer((req, res) => {
            const body = http.STATUS_CODES[426];
            res.writeHead(426, {
              "Content-Length": body.length,
              "Content-Type": "text/plain"
            });
            res.end(body);
          });
          this._server.listen(
            options.port,
            options.host,
            options.backlog,
            callback
          );
        } else if (options.server) {
          this._server = options.server;
        }
        if (this._server) {
          const emitConnection = this.emit.bind(this, "connection");
          this._removeListeners = addListeners(this._server, {
            listening: this.emit.bind(this, "listening"),
            error: this.emit.bind(this, "error"),
            upgrade: (req, socket, head) => {
              this.handleUpgrade(req, socket, head, emitConnection);
            }
          });
        }
        if (options.perMessageDeflate === true) options.perMessageDeflate = {};
        if (options.clientTracking) {
          this.clients = /* @__PURE__ */ new Set();
          this._shouldEmitClose = false;
        }
        this.options = options;
        this._state = RUNNING;
      }
      /**
       * Returns the bound address, the address family name, and port of the server
       * as reported by the operating system if listening on an IP socket.
       * If the server is listening on a pipe or UNIX domain socket, the name is
       * returned as a string.
       *
       * @return {(Object|String|null)} The address of the server
       * @public
       */
      address() {
        if (this.options.noServer) {
          throw new Error('The server is operating in "noServer" mode');
        }
        if (!this._server) return null;
        return this._server.address();
      }
      /**
       * Stop the server from accepting new connections and emit the `'close'` event
       * when all existing connections are closed.
       *
       * @param {Function} [cb] A one-time listener for the `'close'` event
       * @public
       */
      close(cb) {
        if (this._state === CLOSED) {
          if (cb) {
            this.once("close", () => {
              cb(new Error("The server is not running"));
            });
          }
          process.nextTick(emitClose, this);
          return;
        }
        if (cb) this.once("close", cb);
        if (this._state === CLOSING) return;
        this._state = CLOSING;
        if (this.options.noServer || this.options.server) {
          if (this._server) {
            this._removeListeners();
            this._removeListeners = this._server = null;
          }
          if (this.clients) {
            if (!this.clients.size) {
              process.nextTick(emitClose, this);
            } else {
              this._shouldEmitClose = true;
            }
          } else {
            process.nextTick(emitClose, this);
          }
        } else {
          const server = this._server;
          this._removeListeners();
          this._removeListeners = this._server = null;
          server.close(() => {
            emitClose(this);
          });
        }
      }
      /**
       * See if a given request should be handled by this server instance.
       *
       * @param {http.IncomingMessage} req Request object to inspect
       * @return {Boolean} `true` if the request is valid, else `false`
       * @public
       */
      shouldHandle(req) {
        if (this.options.path) {
          const index = req.url.indexOf("?");
          const pathname = index !== -1 ? req.url.slice(0, index) : req.url;
          if (pathname !== this.options.path) return false;
        }
        return true;
      }
      /**
       * Handle a HTTP Upgrade request.
       *
       * @param {http.IncomingMessage} req The request object
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Function} cb Callback
       * @public
       */
      handleUpgrade(req, socket, head, cb) {
        socket.on("error", socketOnError);
        const key = req.headers["sec-websocket-key"];
        const upgrade = req.headers.upgrade;
        const version = +req.headers["sec-websocket-version"];
        if (req.method !== "GET") {
          const message = "Invalid HTTP method";
          abortHandshakeOrEmitwsClientError(this, req, socket, 405, message);
          return;
        }
        if (upgrade === void 0 || upgrade.toLowerCase() !== "websocket") {
          const message = "Invalid Upgrade header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
          return;
        }
        if (key === void 0 || !keyRegex.test(key)) {
          const message = "Missing or invalid Sec-WebSocket-Key header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
          return;
        }
        if (version !== 13 && version !== 8) {
          const message = "Missing or invalid Sec-WebSocket-Version header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message, {
            "Sec-WebSocket-Version": "13, 8"
          });
          return;
        }
        if (!this.shouldHandle(req)) {
          abortHandshake(socket, 400);
          return;
        }
        const secWebSocketProtocol = req.headers["sec-websocket-protocol"];
        let protocols = /* @__PURE__ */ new Set();
        if (secWebSocketProtocol !== void 0) {
          try {
            protocols = subprotocol2.parse(secWebSocketProtocol);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Protocol header";
            abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
            return;
          }
        }
        const secWebSocketExtensions = req.headers["sec-websocket-extensions"];
        const extensions = {};
        if (this.options.perMessageDeflate && secWebSocketExtensions !== void 0) {
          const perMessageDeflate = new PerMessageDeflate2({
            ...this.options.perMessageDeflate,
            isServer: true,
            maxPayload: this.options.maxPayload
          });
          try {
            const offers = extension2.parse(secWebSocketExtensions);
            if (offers[PerMessageDeflate2.extensionName]) {
              perMessageDeflate.accept(offers[PerMessageDeflate2.extensionName]);
              extensions[PerMessageDeflate2.extensionName] = perMessageDeflate;
            }
          } catch (err) {
            const message = "Invalid or unacceptable Sec-WebSocket-Extensions header";
            abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
            return;
          }
        }
        if (this.options.verifyClient) {
          const info = {
            origin: req.headers[`${version === 8 ? "sec-websocket-origin" : "origin"}`],
            secure: !!(req.socket.authorized || req.socket.encrypted),
            req
          };
          if (this.options.verifyClient.length === 2) {
            this.options.verifyClient(info, (verified, code, message, headers) => {
              if (!verified) {
                return abortHandshake(socket, code || 401, message, headers);
              }
              this.completeUpgrade(
                extensions,
                key,
                protocols,
                req,
                socket,
                head,
                cb
              );
            });
            return;
          }
          if (!this.options.verifyClient(info)) return abortHandshake(socket, 401);
        }
        this.completeUpgrade(extensions, key, protocols, req, socket, head, cb);
      }
      /**
       * Upgrade the connection to WebSocket.
       *
       * @param {Object} extensions The accepted extensions
       * @param {String} key The value of the `Sec-WebSocket-Key` header
       * @param {Set} protocols The subprotocols
       * @param {http.IncomingMessage} req The request object
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Function} cb Callback
       * @throws {Error} If called more than once with the same socket
       * @private
       */
      completeUpgrade(extensions, key, protocols, req, socket, head, cb) {
        if (!socket.readable || !socket.writable) return socket.destroy();
        if (socket[kWebSocket]) {
          throw new Error(
            "server.handleUpgrade() was called more than once with the same socket, possibly due to a misconfiguration"
          );
        }
        if (this._state > RUNNING) return abortHandshake(socket, 503);
        const digest = createHash("sha1").update(key + GUID).digest("base64");
        const headers = [
          "HTTP/1.1 101 Switching Protocols",
          "Upgrade: websocket",
          "Connection: Upgrade",
          `Sec-WebSocket-Accept: ${digest}`
        ];
        const ws = new this.options.WebSocket(null, void 0, this.options);
        if (protocols.size) {
          const protocol = this.options.handleProtocols ? this.options.handleProtocols(protocols, req) : protocols.values().next().value;
          if (protocol) {
            headers.push(`Sec-WebSocket-Protocol: ${protocol}`);
            ws._protocol = protocol;
          }
        }
        if (extensions[PerMessageDeflate2.extensionName]) {
          const params = extensions[PerMessageDeflate2.extensionName].params;
          const value = extension2.format({
            [PerMessageDeflate2.extensionName]: [params]
          });
          headers.push(`Sec-WebSocket-Extensions: ${value}`);
          ws._extensions = extensions;
        }
        this.emit("headers", headers, req);
        socket.write(headers.concat("\r\n").join("\r\n"));
        socket.removeListener("error", socketOnError);
        ws.setSocket(socket, head, {
          allowSynchronousEvents: this.options.allowSynchronousEvents,
          maxBufferedChunks: this.options.maxBufferedChunks,
          maxFragments: this.options.maxFragments,
          maxPayload: this.options.maxPayload,
          skipUTF8Validation: this.options.skipUTF8Validation
        });
        if (this.clients) {
          this.clients.add(ws);
          ws.on("close", () => {
            this.clients.delete(ws);
            if (this._shouldEmitClose && !this.clients.size) {
              process.nextTick(emitClose, this);
            }
          });
        }
        cb(ws, req);
      }
    };
    module2.exports = WebSocketServer2;
    function addListeners(server, map) {
      for (const event of Object.keys(map)) server.on(event, map[event]);
      return function removeListeners() {
        for (const event of Object.keys(map)) {
          server.removeListener(event, map[event]);
        }
      };
    }
    function emitClose(server) {
      server._state = CLOSED;
      server.emit("close");
    }
    function socketOnError() {
      this.destroy();
    }
    function abortHandshake(socket, code, message, headers) {
      message = message || http.STATUS_CODES[code];
      headers = {
        Connection: "close",
        "Content-Type": "text/html",
        "Content-Length": Buffer.byteLength(message),
        ...headers
      };
      socket.once("finish", socket.destroy);
      socket.end(
        `HTTP/1.1 ${code} ${http.STATUS_CODES[code]}\r
` + Object.keys(headers).map((h) => `${h}: ${headers[h]}`).join("\r\n") + "\r\n\r\n" + message
      );
    }
    function abortHandshakeOrEmitwsClientError(server, req, socket, code, message, headers) {
      if (server.listenerCount("wsClientError")) {
        const err = new Error(message);
        Error.captureStackTrace(err, abortHandshakeOrEmitwsClientError);
        server.emit("wsClientError", err, socket, req);
      } else {
        abortHandshake(socket, code, message, headers);
      }
    }
  }
});

// server/app.ts
var import_node_http = require("node:http");
var import_promises = require("node:fs/promises");
var import_node_path = require("node:path");
var import_node_crypto = require("node:crypto");

// node_modules/ws/wrapper.mjs
var import_stream = __toESM(require_stream(), 1);
var import_extension = __toESM(require_extension(), 1);
var import_permessage_deflate = __toESM(require_permessage_deflate(), 1);
var import_receiver = __toESM(require_receiver(), 1);
var import_sender = __toESM(require_sender(), 1);
var import_subprotocol = __toESM(require_subprotocol(), 1);
var import_websocket = __toESM(require_websocket(), 1);
var import_websocket_server = __toESM(require_websocket_server(), 1);

// src/game/map.ts
var CELL = 2.2;
var WIDTH = 37;
var HEIGHT = 41;
var LEVELS = 3;
var FLOOR_HEIGHT = 4.8;
var PLAYER_RADIUS = 0.27;
var MONSTER_RADIUS = 0.36;
var toWorld = (x, z, level = 1) => ({ x: (x - (WIDTH - 1) / 2) * CELL, z: (z - (HEIGHT - 1) / 2) * CELL, level });
var toCell = (p) => ({ x: Math.round(p.x / CELL + (WIDTH - 1) / 2), z: Math.round(p.z / CELL + (HEIGHT - 1) / 2), level: p.level ?? 1 });
var distanceXZ = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
var distance = (a, b) => Math.hypot(a.x - b.x, a.z - b.z, ((a.level ?? 1) - (b.level ?? 1)) * FLOOR_HEIGHT);
var START = toWorld(1, 1);
var EXIT = toWorld(WIDTH - 2, HEIGHT - 2);
var MONSTER_START = toWorld(WIDTH - 2, HEIGHT - 4, 0);
var STAIRS = [{ id: "west", x: 5, topZ: 9, bottomZ: 15, lower: 0, upper: 1 }, { id: "east", x: WIDTH - 6, topZ: 23, bottomZ: 29, lower: 1, upper: 2 }];
var seededRandom = (seed) => {
  let a = seed >>> 0;
  return () => {
    a += 1831565813;
    let t = a;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
};
var HospitalMap = class {
  constructor(seed = 1) {
    this.seed = seed;
    const random = seededRandom(seed), reserved = (x, z, l) => STAIRS.some((s) => (l === s.lower || l === s.upper) && Math.abs(x - s.x) <= 1 && z >= s.topZ && z <= s.bottomZ);
    const inside = (x, z) => x > 0 && z > 0 && x < WIDTH - 1 && z < HEIGHT - 1;
    for (let l = 0; l < LEVELS; l++) {
      const grid = this.floors[l], stack = [{ x: 1, z: 1, level: l }];
      grid[1][1] = true;
      while (stack.length) {
        const a = stack[stack.length - 1], dirs = [[2, 0], [-2, 0], [0, 2], [0, -2]];
        for (let i = dirs.length - 1; i > 0; i--) {
          const j = Math.floor(random() * (i + 1));
          [dirs[i], dirs[j]] = [dirs[j], dirs[i]];
        }
        let carved = false;
        for (const [dx, dz] of dirs) {
          const x = a.x + dx, z = a.z + dz;
          if (!inside(x, z) || grid[z][x] || reserved(x, z, l) || reserved(a.x + dx / 2, a.z + dz / 2, l)) continue;
          grid[a.z + dz / 2][a.x + dx / 2] = true;
          grid[z][x] = true;
          stack.push({ x, z, level: l });
          carved = true;
          break;
        }
        if (!carved) stack.pop();
      }
      for (let z = 1; z < HEIGHT - 1; z++) for (let x = 1; x < WIDTH - 1; x++) if (!grid[z][x] && !reserved(x, z, l) && random() < 0.19 && (grid[z][x - 1] && grid[z][x + 1] && !grid[z - 1][x] && !grid[z + 1][x] || grid[z - 1][x] && grid[z + 1][x] && !grid[z][x - 1] && !grid[z][x + 1])) grid[z][x] = true;
      for (let i = 0; i < 5; i++) {
        const x = 3 + 2 * Math.floor(random() * ((WIDTH - 7) / 2)), z = 3 + 2 * Math.floor(random() * ((HEIGHT - 7) / 2));
        for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) if (!reserved(x + dx, z + dz, l)) grid[z + dz][x + dx] = true;
      }
    }
    for (const s of STAIRS) for (const l of [s.lower, s.upper]) {
      for (let z = s.topZ; z <= s.bottomZ; z++) {
        this.floors[l][z][s.x] = true;
        this.floors[l][z][s.x - 1] = false;
        this.floors[l][z][s.x + 1] = false;
      }
      for (const z of [s.topZ - 1, s.bottomZ + 1]) for (let x = s.x - 2; x <= s.x + 2; x++) this.floors[l][z][x] = true;
    }
    this.floors[1][HEIGHT - 3][WIDTH - 2] = true;
    this.floors[1][HEIGHT - 2][WIDTH - 2] = true;
    this.floors[1][HEIGHT - 1][WIDTH - 2] = true;
    this.connectComponents();
    const candidates = [];
    for (let l = 0; l < LEVELS; l++) for (let z = 1; z < HEIGHT - 1; z++) for (let x = 1; x < WIDTH - 1; x++) if (this.isFloor(x, z, l) && !this.stairCell(x, z, l) && distance(toWorld(x, z, l), START) > 7 && !(l === 1 && z >= HEIGHT - 4 && x >= WIDTH - 4)) candidates.push(toWorld(x, z, l));
    for (let i = candidates.length - 1; i > 0; i--) {
      const j = Math.floor(random() * (i + 1));
      [candidates[i], candidates[j]] = [candidates[j], candidates[i]];
    }
    this.pool = candidates;
    const used = [];
    const choose = (level) => {
      const p = candidates.find((p2) => (level === void 0 || p2.level === level) && used.every((q) => distance(p2, q) > 5));
      const value = { ...p ?? candidates[used.length] };
      used.push(value);
      return value;
    };
    this.elevator = choose(1);
    const e = toCell(this.elevator);
    for (let l = 0; l < LEVELS; l++) this.floors[l][e.z][e.x] = true;
    this.connectComponents();
    this.generator = choose(0);
    this.workbench = choose();
    this.spawns = [choose(1), choose(0), choose(2), choose(1)];
    this.patrol = Array.from({ length: 18 }, (_, i) => choose(i % 3));
    for (let l = 0; l < LEVELS; l++) for (let i = 0; i < 9; i++) {
      const p = choose(l), c = toCell(p);
      const dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]], side = dirs.find(([dx, dz]) => !this.isFloor(c.x + dx, c.z + dz, l));
      if (!side) continue;
      const type = i < 2 ? "locker" : i % 4 === 0 ? "radio" : i % 4 === 1 ? "cabinet" : i % 4 === 2 ? "bottles" : "cart";
      this.props.push({ ...p, id: `prop-${l}-${i}`, type, name: { locker: "\u85CF\u8EAB\u67DC", radio: "\u8001\u65E7\u6536\u97F3\u673A", cabinet: "\u91D1\u5C5E\u50A8\u7269\u67DC", bottles: "\u73BB\u7483\u836F\u74F6", cart: "\u751F\u9508\u63A8\u8F66" }[type], noise: type === "locker" ? 3 : type === "radio" ? 43 : type === "bottles" ? 34 : 26, offsetX: side[0] * 0.84, offsetZ: side[1] * 0.84 });
    }
    for (let l = 0; l < LEVELS; l++) {
      let n = 0;
      for (const p of candidates) {
        if (p.level !== l || n >= 5 || used.some((q) => distance(p, q) < 4)) continue;
        const c = toCell(p), g = this.floors[l];
        const horizontal = g[c.z][c.x - 1] && g[c.z][c.x + 1] && !g[c.z - 1][c.x] && !g[c.z + 1][c.x], vertical = g[c.z - 1][c.x] && g[c.z + 1][c.x] && !g[c.z][c.x - 1] && !g[c.z][c.x + 1];
        if (!horizontal && !vertical) continue;
        this.doors.push({ id: `door-${l}-${n++}`, position: { ...p }, cells: [c], open: false, axis: horizontal ? "z" : "x", name: "\u75C5\u533A\u9694\u65AD\u95E8" });
        used.push(p);
      }
    }
  }
  seed;
  floors = Array.from({ length: LEVELS }, () => Array.from({ length: HEIGHT }, () => Array(WIDTH).fill(false)));
  doors = [];
  props = [];
  patrol = [];
  spawns = [];
  pool = [];
  elevator;
  generator;
  workbench;
  gateOpen = false;
  connectComponents() {
    for (let l = 0; l < LEVELS; l++) {
      const grid = this.floors[l], seen = /* @__PURE__ */ new Set(), key = (x, z) => `${x},${z}`;
      const flood = () => {
        const q = [{ x: 1, z: 1, level: l }];
        seen.clear();
        seen.add(key(1, 1));
        for (let i = 0; i < q.length; i++) {
          const a = q[i];
          for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
            const x = a.x + dx, z = a.z + dz;
            if (this.isFloor(x, z, l) && !seen.has(key(x, z))) {
              seen.add(key(x, z));
              q.push({ x, z, level: l });
            }
          }
        }
      };
      flood();
      for (let guard = 0; guard < 100; guard++) {
        let joined = false;
        for (let z = 1; z < HEIGHT - 1 && !joined; z++) for (let x = 1; x < WIDTH - 1 && !joined; x++) {
          if (grid[z][x] || STAIRS.some((s) => (l === s.lower || l === s.upper) && Math.abs(x - s.x) <= 1 && z >= s.topZ && z <= s.bottomZ)) continue;
          const ns = [[1, 0], [-1, 0], [0, 1], [0, -1]].map(([dx, dz]) => ({ x: x + dx, z: z + dz })).filter((p) => this.isFloor(p.x, p.z, l));
          if (ns.some((p) => seen.has(key(p.x, p.z))) && ns.some((p) => !seen.has(key(p.x, p.z)))) {
            grid[z][x] = true;
            joined = true;
          }
        }
        if (!joined) break;
        flood();
      }
    }
  }
  reset() {
    this.gateOpen = false;
    this.doors.forEach((d) => d.open = false);
  }
  isFloor(x, z, l = 1) {
    return this.floors[l]?.[z]?.[x] === true;
  }
  stairCell(x, z, l) {
    return STAIRS.find((s) => x === s.x && z >= s.topZ && z <= s.bottomZ && (l === s.lower || l === s.upper));
  }
  stairAt(p) {
    const c = toCell(p);
    return this.stairCell(c.x, c.z, c.level);
  }
  levelAt(p) {
    const s = this.stairAt(p);
    return s ? p.z < toWorld(s.x, (s.topZ + s.bottomZ) / 2).z ? s.upper : s.lower : p.level ?? 1;
  }
  heightAt(p) {
    const s = this.stairAt(p);
    if (!s) return (p.level ?? 1) * FLOOR_HEIGHT;
    const top = toWorld(s.x, s.topZ).z, bottom = toWorld(s.x, s.bottomZ).z;
    return s.lower * FLOOR_HEIGHT + Math.max(0, Math.min(1, (bottom - p.z) / (bottom - top))) * FLOOR_HEIGHT;
  }
  blocked(x, z, l = 1, ignoreDoors = false) {
    return !this.isFloor(x, z, l) || !this.gateOpen && l === 1 && x === WIDTH - 2 && z === HEIGHT - 2 || !ignoreDoors && this.doors.some((d) => !d.open && d.cells.some((c) => c.x === x && c.z === z && c.level === l));
  }
  navBlocked(x, z, l, ignoreDoors = true) {
    const s = this.stairCell(x, z, l);
    return this.blocked(x, z, l, ignoreDoors) || !!s && l !== (z < (s.topZ + s.bottomZ) / 2 ? s.upper : s.lower);
  }
  neighbors(c, ignoreDoors = true) {
    const result = [];
    for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const x = c.x + dx, z = c.z + dz, s = this.stairCell(x, z, c.level), level = s ? z < (s.topZ + s.bottomZ) / 2 ? s.upper : s.lower : c.level;
      if (!this.navBlocked(x, z, level, ignoreDoors) && Math.abs(this.heightAt(toWorld(x, z, level)) - this.heightAt(toWorld(c.x, c.z, c.level))) < 1.01) result.push({ x, z, level });
    }
    return result;
  }
  decorOffset(p) {
    const c = toCell(p), s = [[1, 0], [-1, 0], [0, 1], [0, -1]].find(([x, z]) => !this.isFloor(c.x + x, c.z + z, c.level)) ?? [1, 0];
    return { x: s[0] * 0.82, z: s[1] * 0.82 };
  }
  canStand(p, radius) {
    const l = this.levelAt(p), c = toCell(p);
    for (const prop of this.props) if (prop.level === l && Math.hypot(p.x - prop.x - prop.offsetX, p.z - prop.z - prop.offsetZ) < radius + 0.23) return false;
    for (const station of [this.generator, this.workbench]) if (station && station.level === l) {
      const offset = this.decorOffset(station);
      if (Math.hypot(p.x - station.x - offset.x, p.z - station.z - offset.z) < radius + 0.28) return false;
    }
    for (let z = c.z - 1; z <= c.z + 1; z++) for (let x = c.x - 1; x <= c.x + 1; x++) {
      if (!this.blocked(x, z, l)) continue;
      const q = toWorld(x, z, l), dx = p.x - Math.max(q.x - CELL / 2, Math.min(p.x, q.x + CELL / 2)), dz = p.z - Math.max(q.z - CELL / 2, Math.min(p.z, q.z + CELL / 2));
      if (dx * dx + dz * dz < radius * radius) return false;
    }
    return true;
  }
  move(p, dx, dz, radius) {
    const n = Math.max(1, Math.ceil(Math.hypot(dx, dz) / (radius * 0.45)));
    for (let i = 0; i < n; i++) {
      const qx = { x: p.x + dx / n, z: p.z, level: p.level };
      if (this.canStand(qx, radius) && Math.abs(this.heightAt(qx) - this.heightAt(p)) < 0.15) {
        p.x = qx.x;
        p.level = this.levelAt(p);
      }
      const qz = { x: p.x, z: p.z + dz / n, level: p.level };
      if (this.canStand(qz, radius) && Math.abs(this.heightAt(qz) - this.heightAt(p)) < 0.15) {
        p.z = qz.z;
        p.level = this.levelAt(p);
      }
    }
  }
  segmentClear(a, b, radius) {
    const n = Math.max(1, Math.ceil(distanceXZ(a, b) / 0.1));
    let l = a.level, h = this.heightAt(a);
    for (let i = 1; i <= n; i++) {
      const p = { x: a.x + (b.x - a.x) * i / n, z: a.z + (b.z - a.z) * i / n, level: l };
      p.level = this.levelAt(p);
      if (!this.canStand(p, radius) || Math.abs(this.heightAt(p) - h) > 0.15) return false;
      l = p.level;
      h = this.heightAt(p);
    }
    return l === b.level;
  }
  lineOfSight(a, b) {
    if (Math.abs(this.heightAt(a) - this.heightAt(b)) > 2.5) return false;
    if ((a.level ?? 1) !== (b.level ?? 1) && !(this.stairAt(a) && this.stairAt(a)?.id === this.stairAt(b)?.id)) return false;
    const n = Math.max(1, Math.ceil(distanceXZ(a, b) / 0.14));
    let l = a.level ?? 1;
    for (let i = 1; i <= n; i++) {
      const p = { x: a.x + (b.x - a.x) * i / n, z: a.z + (b.z - a.z) * i / n, level: l };
      l = this.levelAt(p);
      const c = toCell(p);
      if (this.blocked(c.x, c.z, l)) return false;
    }
    return true;
  }
  openDoorOnPath(p, next) {
    const d = this.doors.find((d2) => !d2.open && d2.cells.some((c) => c.level === (next.level ?? 1) && distanceXZ(toWorld(c.x, c.z, c.level), next) < 0.2));
    if (d && distanceXZ(p, d.position) < 3.4) {
      d.open = true;
      return true;
    }
    return false;
  }
  room(p) {
    if (this.stairAt(p)) return "\u5C01\u95ED\u697C\u68AF\u4E95";
    if (distanceXZ(p, this.elevator) < 2.5) return "\u5347\u964D\u68AF\u5385";
    if (distance(p, this.generator) < 3) return "\u4F9B\u7535\u5BA4";
    if (distance(p, this.workbench) < 3) return "\u7EF4\u4FEE\u5DE5\u4F5C\u95F4";
    return p.level === 0 ? "\u5730\u4E0B\u68C0\u4FEE\u8FF7\u5ECA" : p.level === 2 ? "\u9694\u79BB\u4EA4\u53C9\u901A\u9053" : "\u5C01\u9501\u75C5\u533A";
  }
};

// src/game/navigation.ts
function findPath(map, from, to, ignoreDoors = true) {
  const a = toCell({ ...from, level: map.levelAt(from) }), b = toCell({ ...to, level: map.levelAt(to) });
  if (map.navBlocked(a.x, a.z, a.level, ignoreDoors) || map.navBlocked(b.x, b.z, b.level, ignoreDoors)) return [];
  const layer = WIDTH * HEIGHT, key = (x, z, l) => l * layer + z * WIDTH + x;
  const decode = (id) => ({ x: id % WIDTH, z: Math.floor(id / WIDTH) % HEIGHT, level: Math.floor(id / layer) });
  const start = key(a.x, a.z, a.level), target = key(b.x, b.z, b.level), open = /* @__PURE__ */ new Set([start]);
  const costs = /* @__PURE__ */ new Map([[start, 0]]), parent = /* @__PURE__ */ new Map();
  const h = (id) => {
    const c = decode(id);
    return Math.abs(c.x - b.x) + Math.abs(c.z - b.z) + Math.abs(c.level - b.level) * FLOOR_HEIGHT / CELL;
  };
  while (open.size) {
    let current = -1, best = Infinity;
    for (const id of open) {
      const f = costs.get(id) + h(id);
      if (f < best) {
        best = f;
        current = id;
      }
    }
    if (current === target) {
      const ids = [current];
      while (parent.has(ids[0])) ids.unshift(parent.get(ids[0]));
      return ids.map((id) => {
        const c2 = decode(id);
        return toWorld(c2.x, c2.z, c2.level);
      });
    }
    open.delete(current);
    const c = decode(current);
    for (const n of map.neighbors(c, ignoreDoors)) {
      const id = key(n.x, n.z, n.level), cost = costs.get(current) + 1 + Math.abs(n.level - c.level) * 0.2;
      if (cost < (costs.get(id) ?? Infinity)) {
        costs.set(id, cost);
        parent.set(id, current);
        open.add(id);
      }
    }
  }
  return [];
}

// src/game/monster.ts
var Monster = class {
  constructor(map, start = MONSTER_START) {
    this.map = map;
    Object.assign(this.position, start);
    this.lastSeen = { ...start };
  }
  map;
  position = { ...MONSTER_START };
  state = "patrol";
  lastSeen = { ...MONSTER_START };
  facing = { x: 0, z: -1 };
  path = [];
  grace = 6;
  canSee = false;
  patrolIndex = 1;
  repath = 0;
  lost = 0;
  searching = 0;
  action = 0;
  attackCooldown = 5;
  reset() {
    Object.assign(this.position, MONSTER_START);
    this.state = "patrol";
    this.path = [];
    this.patrolIndex = 1;
    this.repath = 0;
    this.grace = 6;
    this.canSee = false;
    this.lost = 0;
    this.searching = 0;
    this.attackCooldown = 5;
  }
  hear(point, radius) {
    if (this.grace > 0 || this.state === "stunned" || this.canSee) return false;
    const vertical = Math.abs(point.level - this.position.level);
    if (distance(this.position, point) > radius / (1 + vertical * 0.2)) return false;
    this.state = "investigate";
    this.lastSeen = { ...point };
    this.searching = 12;
    this.repath = 0;
    return true;
  }
  stun(seconds = 5) {
    this.state = "stunned";
    this.action = seconds;
    this.canSee = false;
    this.path = [];
  }
  update(dt, player, perception) {
    this.grace = Math.max(0, this.grace - dt);
    this.attackCooldown = Math.max(0, this.attackCooldown - dt);
    if (this.state === "stunned") {
      this.action -= dt;
      if (this.action <= 0) {
        this.state = "search";
        this.searching = 9;
        this.repath = 0;
      }
      return false;
    }
    const d = Math.hypot(distanceXZ(this.position, player), this.map.heightAt(this.position) - this.map.heightAt(player));
    const dot = ((player.x - this.position.x) * this.facing.x + (player.z - this.position.z) * this.facing.z) / Math.max(0.01, d);
    const visible = !perception.hidden && this.grace === 0 && d < (perception.torch ? 24 : 17) && this.map.lineOfSight(this.position, player);
    this.canSee = visible && (dot > -0.25 || d < 5 || ["chase", "windup", "lunge"].includes(this.state));
    if (this.canSee) {
      this.lastSeen = { ...player };
      this.lost = 0;
      this.searching = 0;
      if (!["windup", "lunge"].includes(this.state)) {
        if (this.state !== "chase") this.repath = 0;
        this.state = "chase";
      }
    } else if (["chase", "windup", "lunge"].includes(this.state)) {
      this.lost += dt;
      if (this.lost > 1.7) {
        this.state = "search";
        this.searching = 10;
        this.repath = 0;
      }
    }
    if (this.state === "chase" && this.canSee && d < 5.2 && d > 1.5 && this.attackCooldown <= 0) {
      this.state = "windup";
      this.action = 0.68;
    }
    if (this.state === "windup") {
      this.action -= dt;
      if (this.action <= 0) {
        this.state = "lunge";
        this.action = 0.55;
        this.repath = 0;
        this.attackCooldown = 7;
      }
    } else if (this.state === "lunge") {
      this.action -= dt;
      if (this.action <= 0) this.state = "chase";
    }
    if (this.state === "investigate" && distance(this.position, this.lastSeen) < 1) {
      this.state = "search";
      this.searching = 10;
      this.repath = 0;
    }
    if (this.state === "search") {
      this.searching -= dt;
      if (this.searching <= 0) {
        this.state = "patrol";
        this.repath = 0;
      }
    }
    const target = this.state === "patrol" ? this.map.patrol[this.patrolIndex % this.map.patrol.length] : this.lastSeen;
    if (this.state === "patrol" && distance(this.position, target) < 0.45) {
      this.patrolIndex = (this.patrolIndex + 1) % this.map.patrol.length;
      this.repath = 0;
    }
    this.repath -= dt;
    if (this.repath <= 0) {
      this.path = findPath(this.map, this.position, target);
      if (this.path[0] && (distanceXZ(this.position, this.path[0]) < 0.15 || this.path[1] && this.map.segmentClear(this.position, this.path[1], MONSTER_RADIUS))) this.path.shift();
      if (this.state !== "patrol" && this.path.length) {
        const c = toCell(target), p = toWorld(c.x, c.z, c.level), inset = CELL / 2 - MONSTER_RADIUS - 0.02;
        const goal = { x: Math.max(p.x - inset, Math.min(target.x, p.x + inset)), z: Math.max(p.z - inset, Math.min(target.z, p.z + inset)), level: target.level };
        if (this.map.canStand(goal, MONSTER_RADIUS)) this.path.push(goal);
      }
      this.repath = ["chase", "lunge", "windup"].includes(this.state) ? 0.55 : 1.3;
    }
    let budget = dt * (this.state === "lunge" ? 7 : this.state === "chase" ? 4.45 : this.state === "windup" ? 0.35 : this.state === "patrol" ? 2.5 : 3.1);
    for (let i = 0; i < 4 && this.path.length && budget > 0; i++) {
      const next = this.path[0];
      this.map.openDoorOnPath(this.position, next);
      const dx = next.x - this.position.x, dz = next.z - this.position.z, len = Math.hypot(dx, dz);
      if (len < 0.06) {
        this.path.shift();
        continue;
      }
      const step = Math.min(budget, len);
      this.facing = { x: dx / len, z: dz / len };
      const previous = { ...this.position };
      this.map.move(this.position, dx / len * step, dz / len * step, MONSTER_RADIUS);
      budget -= step;
      if (distanceXZ(previous, this.position) < 1e-3) {
        this.repath = 0;
        break;
      }
      if (distanceXZ(this.position, next) < 0.06) this.path.shift();
    }
    if (this.state === "search" && this.path.length === 0) {
      const angle = dt * 1.5, x = this.facing.x;
      this.facing.x = x * Math.cos(angle) - this.facing.z * Math.sin(angle);
      this.facing.z = x * Math.sin(angle) + this.facing.z * Math.cos(angle);
    }
    return this.grace === 0 && !perception.hidden && d < 1.05 && Math.abs(this.map.heightAt(this.position) - this.map.heightAt(player)) < 1.3 && this.map.lineOfSight(this.position, player);
  }
};

// src/game/items.ts
var ITEM_NAMES = { crowbar: "\u64AC\u68CD", pliers: "\u65AD\u7EBF\u94B3", exitkey: "\u51FA\u53E3\u94A5\u5319", wire: "\u7535\u963B\u4E1D", barrel: "\u67AA\u7BA1\u7EC4\u4EF6", stock: "\u67AA\u6258\u7EC4\u4EF6", trigger: "\u673A\u5323\u7EC4\u4EF6", shell: "\u9730\u5F39", bottle: "\u8BF1\u9975\u74F6", trap: "\u6355\u517D\u5939", shotgun: "\u5355\u7BA1\u9730\u5F39\u67AA" };
function createItems(map) {
  const random = seededRandom(map.seed ^ 33608), pool = map.pool.filter((p) => distance(p, map.generator) > 3 && distance(p, map.workbench) > 3 && distance(p, map.elevator) > 3 && map.doors.every((d) => distance(d.position, p) > 2));
  const kinds2 = ["crowbar", "pliers", "exitkey", "wire", "barrel", "stock", "trigger", "shell", "bottle", "bottle", "bottle", "bottle", "trap", "trap"];
  const used = [];
  return kinds2.map((kind, i) => {
    let p;
    for (let j = 0; j < pool.length; j++) {
      const c = pool[Math.floor(random() * pool.length)];
      if (used.every((q) => distance(q, c) > 4)) {
        p = c;
        break;
      }
    }
    p ??= pool.find((c) => used.every((q) => distance(q, c) > 1));
    used.push(p);
    return { ...p, id: `item-${i}`, kind, name: ITEM_NAMES[kind] };
  });
}
function createStations(map) {
  return [{ ...map.generator, id: "generator", name: "\u4F9B\u7535\u5BA4 \xB7 \u7535\u963B\u4E1D\u63D2\u69FD" }, { ...map.workbench, id: "workbench", name: "\u67AA\u68B0\u5236\u4F5C\u53F0" }, { ...EXIT, z: EXIT.z - 2.2, id: "exit", name: "\u5C01\u9501\u51FA\u53E3" }];
}
var EscapePuzzle = class {
  inventory = /* @__PURE__ */ new Set();
  collected = /* @__PURE__ */ new Set();
  power = false;
  boards = false;
  chain = false;
  unlocked = false;
  bottles = 0;
  traps = 0;
  crafted = false;
  ammo = 0;
  available(item) {
    return !this.collected.has(item.id);
  }
  collect(item) {
    if (!this.available(item)) return false;
    this.collected.add(item.id);
    if (item.kind === "bottle") this.bottles++;
    else if (item.kind === "trap") this.traps++;
    else this.inventory.add(item.kind);
    return true;
  }
  use(station) {
    if (station.id === "generator") {
      if (this.power) return { ok: false, message: "\u4F9B\u7535\u5DF2\u7ECF\u7A33\u5B9A\u3002", noise: 0 };
      if (!this.inventory.has("wire")) return { ok: false, message: "\u7F3A\u5C11\u7535\u963B\u4E1D\u3002", noise: 0 };
      this.inventory.delete("wire");
      this.power = true;
      return { ok: true, message: "\u4F9B\u7535\u6062\u590D\u3002\u8D70\u5ECA\u706F\u4E0E\u5347\u964D\u68AF\u5DF2\u901A\u7535\u3002", noise: 46 };
    }
    if (station.id === "workbench") {
      if (this.crafted) return { ok: false, message: this.ammo ? "\u9730\u5F39\u67AA\u5DF2\u88C5\u586B\uFF0C\u4EC5\u4E00\u53D1\u3002" : "\u672C\u5C40\u552F\u4E00\u4E00\u53D1\u9730\u5F39\u5DF2\u7528\u5B8C\u3002", noise: 0 };
      if (!["barrel", "stock", "trigger", "shell"].every((k) => this.inventory.has(k))) return { ok: false, message: "\u9700\u8981\u67AA\u7BA1\u3001\u67AA\u6258\u3001\u673A\u5323\u548C\u4E00\u53D1\u9730\u5F39\u3002", noise: 0 };
      for (const k of ["barrel", "stock", "trigger", "shell"]) this.inventory.delete(k);
      this.inventory.add("shotgun");
      this.crafted = true;
      this.ammo = 1;
      return { ok: true, message: "\u9730\u5F39\u67AA\u7EC4\u88C5\u5B8C\u6210 \xB7 \u4EC5\u4E00\u53D1 \xB7 \u53EF\u6682\u65F6\u51FB\u9000\u602A\u7269", noise: 25 };
    }
    if (!this.boards) {
      if (!this.inventory.has("crowbar")) return { ok: false, message: "\u6728\u677F\u5C01\u95E8\uFF0C\u9700\u8981\u64AC\u68CD\u3002", noise: 0 };
      this.boards = true;
      return { ok: true, message: "\u6728\u677F\u5DF2\u64AC\u5F00\u3002", noise: 38 };
    }
    if (!this.chain) {
      if (!this.inventory.has("pliers")) return { ok: false, message: "\u9700\u8981\u65AD\u7EBF\u94B3\u526A\u5F00\u94C1\u94FE\u3002", noise: 0 };
      this.chain = true;
      return { ok: true, message: "\u94C1\u94FE\u5DF2\u526A\u65AD\u3002", noise: 22 };
    }
    if (!this.inventory.has("exitkey")) return { ok: false, message: "\u8FD8\u7F3A\u51FA\u53E3\u94A5\u5319\u3002", noise: 0 };
    this.unlocked = true;
    return { ok: true, message: "\u51FA\u53E3\u5DF2\u6253\u5F00\u3002", noise: 34 };
  }
  get checklist() {
    return [this.boards, this.chain, this.inventory.has("exitkey")];
  }
  get progress() {
    return this.checklist.filter(Boolean).length;
  }
  get hint() {
    return "\u5BFB\u627E\u9003\u751F\u5DE5\u5177\uFF0C\u62C6\u9664\u51FA\u53E3\u5C01\u9501\uFF1B\u4F9B\u7535\u4E0E\u67AA\u68B0\u4E3A\u53EF\u9009\u652F\u7EBF\u3002";
  }
  snapshot() {
    return { inventory: [...this.inventory], collected: [...this.collected], power: this.power, boards: this.boards, chain: this.chain, unlocked: this.unlocked, bottles: this.bottles, traps: this.traps, crafted: this.crafted, ammo: this.ammo };
  }
  apply(s) {
    this.inventory.clear();
    s.inventory.forEach((k) => this.inventory.add(k));
    this.collected.clear();
    s.collected.forEach((k) => this.collected.add(k));
    Object.assign(this, { power: s.power, boards: s.boards, chain: s.chain, unlocked: s.unlocked, bottles: s.bottles, traps: s.traps, crafted: s.crafted, ammo: s.ammo });
  }
};

// src/game/flashlight.ts
var Flashlight = class {
  capacity = 180;
  remaining = 180;
  on = false;
  reset() {
    this.remaining = this.capacity;
    this.on = false;
  }
  toggle() {
    if (this.on) {
      this.on = false;
      return "\u624B\u7535\u5173\u95ED";
    }
    if (this.remaining <= 0) return "\u672C\u5C40\u4E09\u5206\u949F\u7167\u660E\u5DF2\u7528\u5C3D";
    this.on = true;
    return "\u624B\u7535\u5F00\u542F";
  }
  update(dt) {
    if (!this.on) return false;
    this.remaining = Math.max(0, this.remaining - Math.max(0, dt));
    if (this.remaining <= 0) {
      this.on = false;
      return true;
    }
    return false;
  }
  get energy() {
    return this.remaining / this.capacity * 100;
  }
};

// src/game/round.ts
var neutralInput = () => ({ x: 0, y: 0, yaw: Math.PI, pitch: 0, sprint: false, crouch: false });
var Round = class {
  constructor(options, members = [{ id: "local", name: "\u8BBF\u5BA2", role: "human", kind: "spider" }]) {
    this.options = options;
    this.map = new HospitalMap(options.seed);
    this.items = createItems(this.map);
    this.stations = createStations(this.map);
    this.random = seededRandom(options.seed ^ 29041);
    const first = this.map.neighbors(toCell(START), false)[0], look = first ? toWorld(first.x, first.z, first.level) : { ...START, z: START.z + 1 }, spawnYaw = Math.atan2(-(look.x - START.x), -(look.z - START.z));
    for (const member of members) {
      const actor = { ...member, ...START, yaw: spawnYaw, pitch: 0, alive: true, escaped: false, hidden: false, compromised: false, stamina: 100, crouch: false, light: new Flashlight(), input: { ...neutralInput(), yaw: spawnYaw }, foot: 0, exhausted: false };
      this.players.set(member.id, actor);
    }
    const controllers = members.filter((p) => p.role === "monster");
    for (let i = 0; i < options.monsterCount; i++) {
      const controller = controllers[i], kind = controller?.kind ?? options.monsterKinds[i % options.monsterKinds.length] ?? "spider", ai = new Monster(this.map, this.map.spawns[i % this.map.spawns.length]);
      ai.grace = 6;
      this.enemies.push({ id: `enemy-${i}`, kind, ai, controller: controller?.id, stun: 0, roar: 7 + this.random() * 13, step: 0, moving: false, attack: 0 });
      if (controller) Object.assign(this.players.get(controller.id), ai.position);
    }
  }
  options;
  map;
  puzzle = new EscapePuzzle();
  items;
  stations;
  players = /* @__PURE__ */ new Map();
  enemies = [];
  traps = [];
  events = [];
  time = 0;
  lightsOn = true;
  finished = false;
  eventSeq = 0;
  lightTimer = 4;
  random;
  pendingNoise = [];
  emit(event) {
    this.events.push({ ...event, point: event.point ? { x: event.point.x, z: event.point.z, level: event.point.level } : void 0, seq: ++this.eventSeq });
    if (this.events.length > 90) this.events.shift();
  }
  input(id, input) {
    const p = this.players.get(id);
    if (!p) return;
    const finite = (x, f = 0) => Number.isFinite(x) ? x : f;
    p.input = { x: Math.max(-1, Math.min(1, finite(input.x))), y: Math.max(-1, Math.min(1, finite(input.y))), yaw: finite(input.yaw), pitch: Math.max(-1.15, Math.min(1.15, finite(input.pitch))), sprint: !!input.sprint, crouch: !!input.crouch };
  }
  noise(point, radius, actor, emit = true) {
    for (const e of this.enemies) if (!e.controller) e.ai.hear(point, radius);
    if (emit) this.emit({ type: "noise", actor, point: { ...point }, value: radius });
  }
  interaction(id) {
    const p = this.players.get(id);
    if (!p || !p.alive || p.escaped || p.lift) return;
    if (p.hidden) return { id: "leave-hide", text: "\u79BB\u5F00\u85CF\u8EAB\u67DC" };
    const candidates = [];
    const near = (q, r) => q.level === p.level && distanceXZ(p, q) < r && this.map.lineOfSight(p, q);
    if (p.role === "human") {
      for (const item of this.items) if (this.puzzle.available(item) && near(item, 1.95)) candidates.push({ id: `item:${item.id}`, text: `\u62FE\u53D6 ${item.name}`, d: distanceXZ(p, item) });
      for (const station of this.stations) if (near(station, station.id === "exit" ? 3 : 2.2) && !(station.id === "generator" && this.puzzle.power) && !(station.id === "exit" && this.puzzle.unlocked)) candidates.push({ id: `station:${station.id}`, text: station.name, d: distanceXZ(p, station) + 0.1 });
      const lift = { ...this.map.elevator, level: p.level };
      if (near(lift, 1.9)) candidates.push({ id: "lift:up", text: this.puzzle.power ? "\u5347\u964D\u68AF \xB7 \u9009\u62E9\u697C\u5C42" : "\u5347\u964D\u68AF \xB7 \u5C1A\u672A\u901A\u7535", d: distanceXZ(p, lift) + 0.2 });
      for (const prop of this.map.props) if (near(prop, 2)) candidates.push({ id: `prop:${prop.id}`, text: prop.type === "locker" ? "\u8FDB\u5165\u85CF\u8EAB\u67DC" : `\u89E6\u78B0 ${prop.name}`, d: distanceXZ(p, prop) + 0.25 });
    }
    for (const d of this.map.doors) if (d.position.level === p.level && distanceXZ(p, d.position) < 2.3) candidates.push({ id: `door:${d.id}`, text: `${d.open ? "\u5173\u95ED" : "\u6253\u5F00"}\u9694\u65AD\u95E8`, d: distanceXZ(p, d.position) + 0.2 });
    candidates.sort((a, b) => a.d - b.d);
    return candidates[0];
  }
  action(id, type, payload) {
    const p = this.players.get(id);
    if (!p || !p.alive || p.escaped || p.lift || this.finished) return;
    p.yaw = p.input.yaw;
    p.pitch = p.input.pitch;
    const message = (text) => this.emit({ type: "message", actor: id, text });
    if (type === "torch") {
      if (p.role !== "human" || p.hidden) return;
      const was = p.light.on, text = p.light.toggle();
      if (was === p.light.on) message(text);
      return;
    }
    if (type === "crouch") {
      p.input.crouch = !p.input.crouch;
      return;
    }
    if (type === "interact") {
      const target = this.interaction(id);
      if (!target) return;
      const [kind, key] = target.id.split(":");
      if (kind === "leave-hide") {
        p.hidden = p.compromised = false;
        return;
      }
      if (kind === "item") {
        const item = this.items.find((i) => i.id === key);
        if (item && this.puzzle.collect(item)) this.emit({ type: "pickup", actor: id, target: item.id, point: { ...item }, text: `\u53D6\u5F97 ${item.name}` });
        return;
      }
      if (kind === "station") {
        const s = this.stations.find((s2) => s2.id === key);
        const result = this.puzzle.use(s);
        message(result.message);
        if (result.ok) {
          if (this.puzzle.power) this.lightsOn = true;
          this.map.gateOpen = this.puzzle.unlocked;
          this.noise(s, result.noise, id, false);
          this.emit({ type: s.id === "generator" ? "power" : s.id === "workbench" ? "craft" : "door", actor: id, point: { ...s } });
        }
        return;
      }
      if (kind === "door") {
        const d = this.map.doors.find((d2) => d2.id === key);
        if (d.open && [...this.players.values(), ...this.enemies.map((e) => e.ai.position)].some((q) => q.level === d.position.level && distanceXZ(q, d.position) < 0.9)) {
          message("\u5148\u79BB\u5F00\u95E8\u6846\u3002");
          return;
        }
        d.open = !d.open;
        this.noise(d.position, 15, id, false);
        this.emit({ type: "door", actor: id, point: { ...d.position } });
        return;
      }
      if (kind === "prop") {
        const prop = this.map.props.find((q) => q.id === key);
        if (prop.type === "locker") {
          p.hidden = true;
          p.light.on = false;
          p.compromised = this.enemies.some((e) => e.ai.canSee && this.map.lineOfSight(e.ai.position, p) && distance(e.ai.position, p) < 15);
        } else this.noise(prop, prop.noise, id);
        return;
      }
      if (kind === "lift") {
        this.action(id, "lift", payload ?? String((p.level + 1) % 3));
        return;
      }
    }
    if (type === "lift" && p.role === "human" && !p.hidden) {
      const level = Number(payload);
      if (!Number.isInteger(level) || level < 0 || level > 2 || level === p.level) return;
      const lift = { ...this.map.elevator, level: p.level };
      if (distanceXZ(p, lift) > 2 || !this.map.lineOfSight(p, lift)) return;
      if (!this.puzzle.power) {
        message("\u9700\u8981\u6062\u590D\u4F9B\u7535\u3002");
        return;
      }
      p.lift = { from: p.level, to: level, elapsed: 0 };
      Object.assign(p, lift);
      p.light.on = false;
      this.emit({ type: "lift", actor: id, point: { ...p } });
      return;
    }
    if (type === "lure" && p.role === "human" && !p.hidden) {
      if (!this.puzzle.bottles) {
        message("\u6CA1\u6709\u8BF1\u9975\u74F6\u3002");
        return;
      }
      this.puzzle.bottles--;
      let end = { ...p };
      for (let d = 0.3; d < 9; d += 0.25) {
        const q = { x: p.x - Math.sin(p.yaw) * d, z: p.z - Math.cos(p.yaw) * d, level: p.level };
        if (!this.map.canStand(q, 0.1) || !this.map.lineOfSight(p, q)) break;
        end = q;
      }
      this.pendingNoise.push({ t: 0.48, p: end, r: 46 });
      return;
    }
    if (type === "trap" && p.role === "human" && !p.hidden) {
      if (!this.puzzle.traps) {
        message("\u6CA1\u6709\u6355\u517D\u5939\u3002");
        return;
      }
      this.puzzle.traps--;
      this.traps.push({ id: `trap-${this.time}`, point: { x: p.x, z: p.z, level: p.level }, active: true });
      this.noise(p, 9, id);
      return;
    }
    if (type === "shoot" && p.role === "human" && !p.hidden) {
      if (!this.puzzle.ammo) {
        message(this.puzzle.crafted ? "\u552F\u4E00\u4E00\u53D1\u9730\u5F39\u5DF2\u8017\u5C3D\u3002" : "\u5C1A\u672A\u7EC4\u88C5\u9730\u5F39\u67AA\u3002");
        return;
      }
      this.puzzle.ammo = 0;
      this.emit({ type: "shot", actor: id, point: { ...p } });
      this.noise(p, 68, id, false);
      const direction = { x: -Math.sin(p.yaw), z: -Math.cos(p.yaw) };
      for (const e of this.enemies) {
        const d = distance(p, e.ai.position), dot = ((e.ai.position.x - p.x) * direction.x + (e.ai.position.z - p.z) * direction.z) / Math.max(0.01, d);
        if (d < 12 && dot > 0.86 && this.map.lineOfSight(p, e.ai.position)) {
          e.stun = 8;
          e.ai.stun(8);
          this.emit({ type: "stun", actor: id, target: e.id, point: { ...e.ai.position } });
        }
      }
      return;
    }
    if (type === "attack" && p.role === "monster") {
      const e = this.enemies.find((e2) => e2.controller === id);
      if (e && !e.stun && e.attack <= 0) {
        e.attack = 0.58;
        e.ai.state = "windup";
        this.emit({ type: "roar", point: { ...p }, target: e.id });
      }
    }
  }
  update(dt) {
    if (this.finished) return;
    const elapsed = Number.isFinite(dt) ? Math.max(0, dt) : 0;
    dt = Math.max(0, Math.min(0.1, elapsed));
    this.time += elapsed;
    this.lightTimer -= elapsed;
    if (this.puzzle.power) this.lightsOn = true;
    else if (this.lightTimer <= 0) {
      this.lightsOn = !this.lightsOn;
      this.lightTimer = this.lightsOn ? 2.8 + this.random() * 6 : 1.8 + this.random() * 4;
    }
    for (const n of this.pendingNoise) {
      n.t -= dt;
      if (n.t <= 0) this.noise(n.p, n.r);
    }
    this.pendingNoise = this.pendingNoise.filter((n) => n.t > 0);
    for (const p of this.players.values()) {
      if (!p.alive || p.escaped) continue;
      p.yaw = p.input.yaw;
      p.pitch = p.input.pitch;
      p.crouch = p.input.crouch;
      if (p.lift) {
        p.lift.elapsed += elapsed;
        if (p.lift.elapsed >= 2.8) {
          p.level = p.lift.to;
          Object.assign(p, { x: this.map.elevator.x, z: this.map.elevator.z });
          p.lift = void 0;
        }
        continue;
      }
      if (p.role === "monster") continue;
      p.light.update(elapsed);
      if (p.hidden) continue;
      if (p.exhausted && p.stamina > 35) p.exhausted = false;
      const len = Math.hypot(p.input.x, p.input.y), moving = len > 0.1, sprint = moving && p.input.sprint && !p.crouch && !p.exhausted && p.stamina > 0;
      p.stamina = Math.max(0, Math.min(100, p.stamina + (sprint ? -26 : 11) * dt));
      if (p.stamina <= 0) p.exhausted = true;
      const speed = p.crouch ? 1.25 : sprint ? 5.25 : 2.55, div = Math.max(1, len), x = p.input.x / div, y = p.input.y / div, previous = { ...p };
      this.map.move(p, (x * Math.cos(p.yaw) - y * Math.sin(p.yaw)) * speed * dt, (-x * Math.sin(p.yaw) - y * Math.cos(p.yaw)) * speed * dt, PLAYER_RADIUS);
      if (distanceXZ(p, previous) > 2e-3) {
        p.foot -= dt;
        if (p.foot <= 0) {
          this.noise(p, p.crouch ? 1.5 : sprint ? 18 : 6, p.id, false);
          p.foot = sprint ? 0.29 : p.crouch ? 0.75 : 0.49;
        }
      }
      if (this.map.gateOpen && p.level === 1 && p.x > EXIT.x - CELL / 2 && p.z > EXIT.z + 0.5) {
        p.escaped = true;
        p.light.on = false;
        this.emit({ type: "escape", actor: p.id, point: { ...p } });
      }
    }
    const humans = [...this.players.values()].filter((p) => p.role === "human" && p.alive && !p.escaped);
    for (const e of this.enemies) {
      const old = { ...e.ai.position };
      e.stun = Math.max(0, e.stun - dt);
      e.attack = Math.max(0, e.attack - dt);
      e.roar -= dt;
      e.step -= dt;
      if (e.controller) {
        const p = this.players.get(e.controller);
        e.ai.grace = Math.max(0, e.ai.grace - dt);
        if (p && p.alive && !e.stun) {
          e.ai.state = e.attack > 0.3 ? "windup" : e.attack > 0 ? "lunge" : Math.hypot(p.input.x, p.input.y) > 0.1 ? "chase" : "search";
          const div = Math.max(1, Math.hypot(p.input.x, p.input.y)), x = p.input.x / div, y = p.input.y / div, speed = 4.45;
          this.map.move(e.ai.position, (x * Math.cos(p.yaw) - y * Math.sin(p.yaw)) * speed * dt, (-x * Math.sin(p.yaw) - y * Math.cos(p.yaw)) * speed * dt, MONSTER_RADIUS);
          e.ai.facing = { x: -Math.sin(p.yaw), z: -Math.cos(p.yaw) };
        }
        if (p) Object.assign(p, e.ai.position);
      } else if (humans.length) {
        const targets = humans.filter((p) => !p.hidden || p.compromised), target = targets.sort((a, b) => distance(e.ai.position, a) - (e.ai.lastSeen === a ? 4 : 0) - (distance(e.ai.position, b) - (e.ai.lastSeen === b ? 4 : 0)))[0] ?? humans[0];
        e.ai.update(dt, target, { hidden: target.hidden && !target.compromised, sprinting: target.input.sprint, torch: target.light.on });
      }
      e.moving = distanceXZ(old, e.ai.position) > 1e-3;
      if (e.roar <= 0 && !e.stun) {
        this.emit({ type: "roar", point: { ...e.ai.position }, target: e.id });
        e.roar = 10 + this.random() * 19;
      }
      for (const t of this.traps) if (t.active && t.point.level === e.ai.position.level && distanceXZ(t.point, e.ai.position) < 0.8) {
        t.active = false;
        e.stun = 6;
        e.ai.stun(6);
        this.emit({ type: "stun", target: e.id, point: { ...e.ai.position } });
      }
      if (e.stun || e.ai.grace > 0 || e.controller && !(e.attack > 0 && e.attack <= 0.3)) continue;
      for (const p of humans) if (p.alive && (!p.hidden || p.compromised) && !p.lift && distance(e.ai.position, p) < 1.04 && this.map.lineOfSight(e.ai.position, p)) {
        p.alive = false;
        p.light.on = false;
        p.caughtBy = e.id;
        this.emit({ type: "caught", actor: p.id, target: e.id, point: { ...p } });
      }
    }
    if (![...this.players.values()].some((p) => p.role === "human" && p.alive && !p.escaped)) this.finished = true;
  }
  snapshot() {
    return { seed: this.options.seed, time: this.time, lightsOn: this.lightsOn, puzzle: this.puzzle.snapshot(), actors: [...this.players.values()].map((p) => ({ id: p.id, name: p.name, role: p.role, kind: p.kind, x: p.x, z: p.z, level: p.level, yaw: p.yaw, pitch: p.pitch, alive: p.alive, escaped: p.escaped, hidden: p.hidden, compromised: p.compromised, stamina: p.stamina, crouch: p.crouch, lightOn: p.light.on, lightRemaining: p.light.remaining, moving: Math.hypot(p.input.x, p.input.y) > 0.1, caughtBy: p.caughtBy, lift: p.lift })), enemies: this.enemies.map((e) => ({ ...e.ai.position, id: e.id, kind: e.kind, controller: e.controller, yaw: Math.atan2(-e.ai.facing.x, -e.ai.facing.z), state: e.ai.state, stun: e.stun, moving: e.moving })), doors: this.map.doors.map((d) => d.open), traps: this.traps, events: this.events, finished: this.finished };
  }
  apply(s) {
    this.time = s.time;
    this.lightsOn = s.lightsOn;
    this.finished = s.finished;
    this.puzzle.apply(s.puzzle);
    this.map.gateOpen = s.puzzle.unlocked;
    this.map.doors.forEach((d, i) => d.open = !!s.doors[i]);
    this.traps = s.traps;
    this.events = s.events;
    for (const a of s.actors) {
      let p = this.players.get(a.id);
      if (!p) {
        p = { ...a, light: new Flashlight(), input: neutralInput(), foot: 0, exhausted: false };
        this.players.set(a.id, p);
      }
      Object.assign(p, a);
      p.input.x = a.moving ? 1 : 0;
      p.input.y = 0;
      p.light.on = a.lightOn;
      p.light.remaining = a.lightRemaining;
    }
    for (const state of s.enemies) {
      const e = this.enemies.find((e2) => e2.id === state.id);
      if (e) {
        Object.assign(e.ai.position, state);
        e.ai.facing = { x: -Math.sin(state.yaw), z: -Math.cos(state.yaw) };
        e.ai.state = state.state;
        e.stun = state.stun;
        e.moving = state.moving;
      }
    }
  }
};

// src/game/characters.ts
var newSeed = () => {
  const values = new Uint32Array(1);
  if (globalThis.crypto?.getRandomValues) globalThis.crypto.getRandomValues(values);
  else values[0] = Math.random() * 4294967295;
  return values[0] || 1;
};

// server/app.ts
var kinds = ["spider", "warden", "silent", "butcher"];
var safeName = (x) => typeof x === "string" ? x.replace(/[\u0000-\u001f\u007f]/g, "").trim().slice(0, 16) || "\u8BBF\u5BA2" : "\u8BBF\u5BA2";
var send = (ws, value) => {
  if (ws.readyState === import_websocket.default.OPEN && ws.bufferedAmount < 1e6) ws.send(JSON.stringify(value));
};
async function startGameServer(options = {}) {
  const rooms = /* @__PURE__ */ new Map(), clients = /* @__PURE__ */ new Map(), root = (0, import_node_path.resolve)(options.staticDir ?? "dist");
  const server = (0, import_node_http.createServer)(async (req, res) => {
    let path;
    try {
      path = new URL(req.url ?? "/", "http://localhost").pathname;
    } catch {
      res.writeHead(400);
      res.end();
      return;
    }
    if (path === "/healthz") {
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ ok: true, rooms: rooms.size, version: "3.0.0" }));
      return;
    }
    let file;
    try {
      file = (0, import_node_path.resolve)(root, "." + decodeURIComponent(path === "/" ? "/index.html" : path));
    } catch {
      res.writeHead(400);
      res.end();
      return;
    }
    if (file !== root && !file.startsWith(root + import_node_path.sep)) {
      res.writeHead(403);
      res.end();
      return;
    }
    try {
      if (!(await (0, import_promises.stat)(file)).isFile()) throw new Error();
      const mime = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css", ".png": "image/png", ".jpg": "image/jpeg", ".svg": "image/svg+xml", ".wav": "audio/wav", ".mp4": "video/mp4", ".webmanifest": "application/manifest+json" };
      const data = await (0, import_promises.readFile)(file), type = mime[(0, import_node_path.extname)(file)] ?? "application/octet-stream";
      const range = req.headers.range?.match(/^bytes=(\d+)-(\d*)$/);
      const headers = { "Content-Type": type, "Cache-Control": /sw\.js$|index\.html$|webmanifest$/.test(file) ? "no-cache" : "public, max-age=3600", "Accept-Ranges": "bytes" };
      if (range) {
        const from = Number(range[1]), to = Math.min(data.length - 1, range[2] ? Number(range[2]) : data.length - 1);
        if (from > to) {
          res.writeHead(416, { "Content-Range": `bytes */${data.length}` });
          res.end();
          return;
        }
        res.writeHead(206, { ...headers, "Content-Range": `bytes ${from}-${to}/${data.length}`, "Content-Length": to - from + 1 });
        res.end(data.subarray(from, to + 1));
      } else {
        res.writeHead(200, { ...headers, "Content-Length": data.length });
        res.end(data);
      }
    } catch {
      if (path === "/") {
        res.writeHead(200, { "Content-Type": "application/json; charset=utf-8" });
        res.end(JSON.stringify({ service: "Midnight Escape room server", version: "3.0.0", ready: true, message: "\u623F\u95F4\u670D\u52A1\u5668\u5DF2\u5C31\u7EEA\uFF0C\u8BF7\u5728\u6E38\u620F\u5927\u5385\u586B\u5165\u6B64 HTTPS \u5730\u5740\u3002" }));
      } else {
        res.writeHead(404);
        res.end("Not found");
      }
    }
  });
  const wss = new import_websocket_server.default({ server, path: "/ws", maxPayload: 65536 });
  const lobby = (room) => ({ type: "lobby", code: room.code, host: room.host, options: room.options, started: !!room.round, players: [...room.clients.values()].map(({ id, name, role, kind }) => ({ id, name, role, kind })) });
  const broadcast = (room, message) => room.clients.forEach((c) => send(c.socket, message));
  const leave = (c) => {
    const room = c.room;
    if (!room) return;
    room.clients.delete(c.id);
    if (room.round) {
      const p = room.round.players.get(c.id);
      if (p) p.alive = false;
      for (const e of room.round.enemies) if (e.controller === c.id) e.controller = void 0;
    }
    c.room = void 0;
    c.mic = false;
    if (!room.clients.size) {
      rooms.delete(room.code);
      return;
    }
    if (room.host === c.id) room.host = room.clients.keys().next().value;
    broadcast(room, lobby(room));
  };
  wss.on("connection", (socket, req) => {
    const allowed = process.env.ALLOWED_ORIGINS?.split(",").map((s) => s.trim());
    if (allowed?.length && (!req.headers.origin || !allowed.includes(req.headers.origin))) {
      socket.close(1008, "Origin not allowed");
      return;
    }
    const id = (0, import_node_crypto.randomBytes)(9).toString("base64url"), c = { id, name: "\u8BBF\u5BA2", role: "human", kind: "spider", socket, packets: 0, window: Date.now(), lastSeen: Date.now(), mic: false };
    clients.set(id, c);
    send(socket, { type: "hello", id, version: "3.0.0" });
    socket.on("pong", () => c.lastSeen = Date.now());
    socket.on("close", () => {
      leave(c);
      clients.delete(id);
    });
    socket.on("error", () => {
    });
    socket.on("message", (raw) => {
      if (Date.now() - c.window > 1e3) {
        c.window = Date.now();
        c.packets = 0;
      }
      if (++c.packets > 80) {
        socket.close(1008, "Rate limit");
        return;
      }
      let m;
      try {
        m = JSON.parse(raw.toString());
      } catch {
        return;
      }
      if (!m || typeof m.type !== "string") return;
      c.lastSeen = Date.now();
      const error = (message) => send(socket, { type: "error", message });
      if (m.type === "create" || m.type === "join") {
        if (c.room) {
          error("\u8BF7\u5148\u79BB\u5F00\u5F53\u524D\u623F\u95F4\u3002");
          return;
        }
        c.name = safeName(m.name);
        c.role = m.role === "monster" ? "monster" : "human";
        c.kind = kinds.includes(m.kind) ? m.kind : "spider";
        let room2;
        if (m.type === "create") {
          if (rooms.size >= 16) {
            error("\u670D\u52A1\u5668\u623F\u95F4\u5DF2\u6EE1\u3002");
            return;
          }
          const count2 = Math.max(1, Math.min(4, Math.floor(Number(m.options?.monsterCount) || 1))), humanSlots = Math.max(1, Math.min(8, Math.floor(Number(m.options?.humanSlots) || 4)));
          const requested = Array.isArray(m.options?.monsterKinds) ? m.options.monsterKinds : [];
          const roundOptions = { seed: 0, monsterCount: count2, humanSlots, monsterKinds: Array.from({ length: count2 }, (_, i) => kinds.includes(requested[i]) ? requested[i] : "spider") };
          let code = "";
          do {
            code = (0, import_node_crypto.randomBytes)(4).toString("hex").slice(0, 7).toUpperCase();
          } while (rooms.has(code));
          room2 = { code, host: id, clients: /* @__PURE__ */ new Map(), options: roundOptions, startsAt: 0, emptyAt: 0 };
          rooms.set(code, room2);
        } else room2 = rooms.get(String(m.code ?? "").toUpperCase().trim());
        if (!room2) {
          error("\u623F\u95F4\u4E0D\u5B58\u5728\u3002");
          return;
        }
        if (room2.round && !room2.round.finished) {
          error("\u6B64\u623F\u95F4\u5DF2\u5F00\u59CB\uFF0C\u8BF7\u7B49\u5F85\u672C\u5C40\u7ED3\u675F\u3002");
          return;
        }
        const count = [...room2.clients.values()].filter((p) => p.role === c.role).length, limit = c.role === "human" ? room2.options.humanSlots : room2.options.monsterCount;
        if (count >= limit) {
          error("\u6B64\u9635\u8425\u4EBA\u6570\u5DF2\u6EE1\u3002");
          return;
        }
        c.room = room2;
        room2.clients.set(id, c);
        send(socket, { type: "joined", id });
        broadcast(room2, lobby(room2));
        return;
      }
      const room = c.room;
      if (!room) return;
      if (m.type === "leave") {
        leave(c);
        return;
      }
      if (m.type === "start") {
        if (room.host !== id) {
          error("\u53EA\u6709\u623F\u4E3B\u53EF\u4EE5\u5F00\u59CB\u3002");
          return;
        }
        if (room.round && !room.round.finished) {
          error("\u672C\u5C40\u4ECD\u5728\u8FDB\u884C\u3002");
          return;
        }
        if (![...room.clients.values()].some((p) => p.role === "human")) {
          error("\u81F3\u5C11\u9700\u8981\u4E00\u540D\u4EBA\u7C7B\u73A9\u5BB6\u3002");
          return;
        }
        room.options = { ...room.options, seed: newSeed() };
        room.round = new Round(room.options, [...room.clients.values()].map(({ id: id2, name, role, kind }) => ({ id: id2, name, role, kind })));
        room.startsAt = Date.now() + (options.startDelay ?? 7900);
        broadcast(room, { type: "start", options: room.options, players: [...room.clients.values()].map(({ id: id2, name, role, kind }) => ({ id: id2, name, role, kind })), startsAt: room.startsAt, serverTime: Date.now() });
        return;
      }
      if (m.type === "chat") {
        const text = typeof m.text === "string" ? m.text.replace(/[\u0000-\u001f\u007f]/g, "").trim().slice(0, 160) : "";
        if (text) {
          for (const peer of room.clients.values()) if (peer.role === c.role) send(peer.socket, { type: "chat", id: c.id, name: c.name, text });
        }
        return;
      }
      if (m.type === "voice") {
        if (!c.mic || typeof m.data !== "string" || m.data.length !== 1280 || !/^[A-Za-z0-9+/]+={0,2}$/.test(m.data)) return;
        for (const peer of room.clients.values()) if (peer.id !== id && peer.role === c.role && peer.socket.bufferedAmount < 32768) send(peer.socket, { type: "voice", from: id, data: m.data });
        return;
      }
      if (m.type === "mic") {
        c.mic = !!m.state;
        for (const peer of room.clients.values()) if (peer.role === c.role) send(peer.socket, { type: "mic", id, state: !!m.state });
        return;
      }
      if (!room.round || Date.now() < room.startsAt) return;
      if (m.type === "input" && m.input && typeof m.input === "object") room.round.input(id, m.input);
      if (m.type === "action" && typeof m.action === "string") room.round.action(id, m.action, typeof m.payload === "string" ? m.payload : void 0);
    });
  });
  let last = Date.now(), frame = 0;
  const timer = setInterval(() => {
    const now = Date.now(), dt = (now - last) / 1e3;
    last = now;
    frame++;
    for (const room of rooms.values()) if (room.round) {
      if (now >= room.startsAt) room.round.update(dt);
      if (frame % 2 === 0) broadcast(room, { type: "snapshot", state: room.round.snapshot() });
    }
  }, 50);
  const heartbeat = setInterval(() => {
    for (const c of clients.values()) {
      if (Date.now() - c.lastSeen > 45e3) c.socket.terminate();
      else c.socket.ping();
    }
  }, 15e3);
  await new Promise((done) => server.listen(options.port ?? Number(process.env.PORT ?? 8787), options.host ?? "0.0.0.0", done));
  return { server, rooms, port: server.address().port, close: async () => {
    clearInterval(timer);
    clearInterval(heartbeat);
    for (const c of clients.values()) c.socket.terminate();
    await new Promise((done) => wss.close(() => server.close(() => done())));
  } };
}

// server/standalone.ts
startGameServer().then((s) => console.log(`Midnight Escape room server listening on ${s.port}`)).catch((e) => {
  console.error(e.message);
  process.exitCode = 1;
});
